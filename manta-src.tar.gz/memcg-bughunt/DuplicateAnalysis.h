#pragma once
#include "Utils.h"

class AllocatorCollector;


// alloc-charging mapping analysis
class DuplicateAnalysis {
public:
    enum AnalysisKind {CHARGE, UNCHARGE};
    DuplicateAnalysis(llvm::Module &module, AllocatorCollector *ac) : _module_(&module), _allocator_collector_(ac) {}
    bool getResult(int type);
private:
    llvm::Module* _module_;
    AllocatorCollector *_allocator_collector_;
    bool dupChargeAnalysis();
    bool dupUnchargeAnalysis();
    bool handleRecord(std::vector<std::pair<llvm::CallInst*, int>>);
    bool isDupCall(llvm::CallInst *, llvm::CallInst *, int, int);
};
    