#pragma once
#include "Utils.h"

enum RET_TYPE {
    VOID_PTR,
    PAGE_PTR,
    ELSE
};

class MemAllocator {
public:
    MemAllocator(llvm::Function* f, unsigned flagIndex, int accountOffset, bool isExported, RET_TYPE retType) : 
        _allocfunc_(f), _flag_arg_index_(flagIndex), _account_offset_(accountOffset), _is_exported_(isExported), _ret_type_(retType) {}
    // bool operator < (const MemAllocator &);
    llvm::Function *getFunction();
    unsigned getFlagArgIndex();
    int getAccountOffset();
    bool isKMCAllocator();
    bool isExported();
    RET_TYPE getRetType();
    static MemAllocator* newKMCreator(llvm::Function *);
protected:
    /* allocator function */
    llvm::Function *_allocfunc_;
    /* the index of the argument holding the gfp flag */
    unsigned _flag_arg_index_;
    /* the bit offset of the accounting bit */
    int _account_offset_;
    /* whether this MemAllocator is exported */
    bool _is_exported_;
    /* store the return type of the _allocfunc_ */
    RET_TYPE _ret_type_;
};

class AllocatorCollector {
public:
    AllocatorCollector(llvm::Module &M);
    MemAllocator* getMemAllocator(llvm::Function*);
    std::set<llvm::Function*> getAllocateFunctions();
    bool isAllocator(llvm::Function *);
private:
    void __addNewAllocator(llvm::Function*, int, int, RET_TYPE);
    void __removeAllocator(llvm::Function*);
    void __collectAllAllocators();
    bool __recursive_checkAllocator(llvm::Function*, llvm::Function*, llvm::CallBase*, std::unordered_set<llvm::Function*>);
    std::set<MemAllocator*> _alloctor_set_;
    std::set<llvm::Function*> _function_set_;
    std::map<llvm::Function*, MemAllocator*> _allocator_map_;
    llvm::Module* _module_;
};