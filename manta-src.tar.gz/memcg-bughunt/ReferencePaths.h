#pragma once
#include "Utils.h"

/*
** Given a target allocation site
**         ptr = kmalloc(...);
** We want to find aliases to the ptr
** We do this by finding reference paths to the ptr
** If we have a reference path <10, 20, 30> bounded to value x
** Then:
**        *(*(x + 10) + 20) + 30
** is an alias of ptr
*/

class ReferencePaths {
public:
    using Path = std::deque<long>;
    using RP = std::pair<llvm::Value*, Path>;
    ReferencePaths(llvm::Function* function) : _function_(function), _leakedToGlobal_(false) {}
    bool addPath(llvm::Value*, Path&);
    bool addPath(llvm::Value*, Path&&);
    Path getPath(llvm::Value*);
    bool isLeakedToGlobal();
    const std::vector<llvm::CallInst *> &getRelatedCalls();
    const std::vector<llvm::ReturnInst *> &getRelatedReturns();
    const std::vector<llvm::Argument *> &getRelatedArguments();
    llvm::Function *getFunction();
    void print(llvm::raw_ostream &);
private:
    bool update();
    bool updateForDef(llvm::Value *, const Path &);
    bool updateForUse(llvm::Value *, const Path &);
    template <typename T>
    bool addElementNodup(std::vector<T*> &vector, T* new_element) {
        for(auto &e : vector) {
            if (e == new_element)
                return false;
        }
        vector.push_back(new_element);
        return true;
    }
    inline void updateData(llvm::Value *, const Path &);
    llvm::Function* _function_;
    bool _leakedToGlobal_;
    std::deque<RP> _pqueue_;
    std::map<llvm::Value*, Path> _result_;
    std::vector<llvm::CallInst *> _relatedCalls_;
    std::vector<llvm::ReturnInst *> _relatedReturns_;
    std::vector<llvm::Argument *> _relatedArguments_;

};