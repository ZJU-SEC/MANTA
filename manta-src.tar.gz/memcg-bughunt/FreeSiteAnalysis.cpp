#include "FreeSiteAnalysis.h"
#include "PexCallGraph.h"
#include "AllocatorCollector.h"
#include "FreeInterfaceCollector.h"

extern PexCallGraph gCallGraph;

const long FreeSiteAnalysis::min_err_no = -4096L;
std::mutex FreeSiteAnalysis::_mutex_;
std::map<llvm::Function*, llvm::PostDominatorTree*> FreeSiteAnalysis::_functopdt_;

FreeSiteAnalysis::FreeSiteAnalysis(llvm::CallInst *allocsite, AllocatorCollector *allocfuncs) {
    _allocsite_ = allocsite;
    _module_ = allocsite->getModule();
    _hoplimit_ = 10;
    _allocfuncs_ = allocfuncs;
    findFreeSites();
}

/*
** BFS search free sites of the given allocation
*/
bool FreeSiteAnalysis::findFreeSites() {
    SearchTask st(_allocsite_->getFunction());
    st.reference_paths.addPath(_allocsite_, {0});
    st.callinst = _allocsite_;
    st.cur_hop = 0;
    _pqueue_.push_back(st);
    while (_pqueue_.size()) {
        ReferencePaths &currp = _pqueue_.front().reference_paths;
        _visitedfunc_.insert(currp.getFunction());
        if (_allocfuncs_->isAllocator(currp.getFunction())) {
            _pqueue_.pop_front();
            continue;
        }
        llvm::CallInst *freesite = findFreeSite(currp, _pqueue_.front().callinst);
        auto related_returns = currp.getRelatedReturns();
        auto related_args = currp.getRelatedArguments();
        if (freesite != nullptr) {
            _freesites_.insert(std::make_pair(currp.getFunction(), freesite));
        }
        else if (allowNext(_pqueue_.front())) {
            auto callsites = gCallGraph.findCallSites(currp.getFunction());
            for (auto &callsite : callsites) {
                auto *nextfn = callsite->getFunction();
                if (!nextfn || isVisited(nextfn) || nextfn->isIntrinsic())
                    continue;
                SearchTask newst(nextfn);
                newst.callinst = callsite;
                newst.cur_hop = _pqueue_.front().cur_hop + 1;
                // only consider the first returninst
                if (related_returns.size()) {
                    newst.reference_paths.addPath(callsite, currp.getPath(related_returns.front()->getReturnValue()));
                }
                for (auto &arg : related_args) {
                    if (arg->getArgNo() >= callsite->getNumArgOperands()) {
                        llvm::errs() << currp.getFunction()->getName() << "\n";
                        llvm::errs() << nextfn->getName() << "\n";
                    }
                    newst.reference_paths.addPath(callsite->getArgOperand(arg->getArgNo()), currp.getPath(arg));
                }
                _pqueue_.push_back(newst);
            }
        }
        _pqueue_.pop_front();
    }
    return true;
}

/*
** handler for one function in BFS search
*/
llvm::CallInst* FreeSiteAnalysis::findFreeSite(ReferencePaths &reference_paths, llvm::CallInst *callinst) {
    _callcontext_.push_back(&reference_paths);
    llvm::PostDominatorTree *pdt = createReachablePDT(reference_paths.getFunction());
    llvm::CallInst *freecall = nullptr;
    llvm::BasicBlock *freebb = nullptr;
    llvm::BasicBlock *targetbb = nullptr;
    for (unsigned i = 0; i < reference_paths.getRelatedCalls().size(); ++i) {
        auto *ci = reference_paths.getRelatedCalls()[i];
        // prune all CIs that cannot be reached from the allocation
        if (ci != callinst && llvm::isPotentiallyReachable(callinst->getParent(), ci->getParent()) && evalCallInst(ci)){
            freecall = ci;
            freebb = ci->getParent();
            break;
        }
    }
    if (freecall == nullptr)
        goto ret;
    if (reference_paths.getPath(callinst).size() != 0) {
        std::vector<llvm::ICmpInst*> icmpinsts = find_phi_select_user<llvm::ICmpInst>(callinst);
        llvm::BasicBlock *bb_pass_ec = nullptr;
        llvm::BasicBlock *bb_pass_nc = nullptr;
        for (auto &inst : icmpinsts) {
            if (isIntegerCheckICmp(inst, min_err_no, llvm::CmpInst::Predicate::ICMP_UGT)) {
                bb_pass_ec = findTargetBasicBlock(inst);
            }
            else if (isNullCheckICmp(inst)) {
                bb_pass_nc = findTargetBasicBlock(inst);
            }
        }
        if (bb_pass_ec == nullptr && bb_pass_nc == nullptr && pdt->dominates(freebb, callinst->getParent()))
            goto ret;
        if (bb_pass_ec && pdt->dominates(freebb, bb_pass_ec))
            goto ret;
        if (bb_pass_nc && pdt->dominates(freebb, bb_pass_nc))
            goto ret;
    }
    else {
        // return ptr by parameter
        if (pdt->dominates(freebb, callinst->getParent()))
            goto ret;
    }
    freecall = nullptr;
    ret:
    _callcontext_.pop_back();
    return freecall;
}

/*
** recursively evaluate whether the call must free the given allocation
*/
bool FreeSiteAnalysis::evalCallInst(llvm::CallInst *callinst) {
    ReferencePaths *toprp = _callcontext_.back();
    llvm::Module *module = toprp->getFunction()->getParent();
    std::vector<llvm::Function *> target_funcs;
    std::vector<llvm::Value *> call_args;
    // boundary condition check
    auto *free_obj = FreeInterfaceCollector::getFreedObject(callinst);
    if (free_obj) {
        auto path = toprp->getPath(free_obj);
        if (path.size() == 1 && path.front() == 0)
            goto ret_true;
        goto ret_false;
    }
    if (_allocfuncs_->isAllocator(callinst->getCalledFunction())) {
        goto ret_false;
    }
    if (_callcontext_.size() == _hoplimit_)
        goto ret_false;
    // end boundary condition check

    if (callinst->getCalledFunction() == module->getFunction("call_rcu")) {
        llvm::Function *rcu_func = llvm::dyn_cast<llvm::Function>(stripConstCastExpr(callinst->getArgOperand(1)));
        if (rcu_func == nullptr)
            goto ret_false;
        target_funcs.push_back(rcu_func);
        call_args.push_back(callinst->getArgOperand(0));
    }
    else {
        // no need to lock here
        std::vector<llvm::Function*> call_targets = gCallGraph.findCallTargets(callinst);
        for (auto &ct : call_targets) {
            if (ct != nullptr && !isVisited(ct) && !ct->isVarArg() && !ct->isIntrinsic()){
                target_funcs.push_back(ct);
            }
        }
        for (auto &arg : callinst->args()) {
            call_args.push_back(arg);
        }
    }
    if (target_funcs.size() != 1)
        goto ret_false;
    for (auto &target_func : target_funcs) {
        llvm::PostDominatorTree *pdt = createReachablePDT(target_func);
        ReferencePaths *newrp = new ReferencePaths(target_func);
        bool eval_res = false;
        for (unsigned i = 0; i < call_args.size(); ++i) {
            auto arg_path = toprp->getPath(call_args[i]);
            if (arg_path.size()) {
                newrp->addPath(target_func->getArg(i), arg_path);
            }
        }
        _callcontext_.push_back(newrp);
        for (unsigned i = 0; i < newrp->getRelatedCalls().size(); ++i) {
            auto *rc = newrp->getRelatedCalls()[i];
            if (evalCallInst(rc) && pdt->dominates(rc->getParent(), &target_func->getEntryBlock())) {
                eval_res = true;
            }
        }
        if (newrp->getRelatedReturns().size()) {
            toprp->addPath(callinst, newrp->getPath(newrp->getRelatedReturns().front()->getReturnValue()));
        }
        for (auto arg : newrp->getRelatedArguments()) {
            toprp->addPath(call_args[arg->getArgNo()], newrp->getPath(arg));
        }
        _callcontext_.pop_back();
        delete newrp;
        if (!eval_res)
            goto ret_false;
    }
    ret_true:
    return true;
    ret_false:
    return false;
}

bool FreeSiteAnalysis::isIntegerCheckICmp(llvm::ICmpInst *icmpinst, long integer, llvm::CmpInst::Predicate predicate) {
    if (icmpinst->getUnsignedPredicate() == predicate) {
        llvm::Value *op = icmpinst->getOperand(0);
        if (auto *constop = llvm::dyn_cast<llvm::Constant>(icmpinst->getOperand(0))) {
            auto *conststrip = stripConstCastExpr(constop);
            if (auto *constint = llvm::dyn_cast<llvm::ConstantInt>(conststrip)) {
                if (constint->getSExtValue() == integer) {
                    return true;
                }
            }
        }
        else if (auto constop = llvm::dyn_cast<llvm::Constant>(icmpinst->getOperand(1))) {
            auto *conststrip = stripConstCastExpr(constop);
            if (auto *constint = llvm::dyn_cast<llvm::ConstantInt>(conststrip)) {
                if (constint->getSExtValue() == integer) {
                    return true;
                }
            }
        }
    }
    return false;
}

bool FreeSiteAnalysis::isNullCheckICmp(llvm::ICmpInst *icmpinst) {
    if (icmpinst->getUnsignedPredicate() == llvm::CmpInst::Predicate::ICMP_EQ) {
        llvm::Value *op = icmpinst->getOperand(0);
        if (auto *constop = llvm::dyn_cast<llvm::Constant>(icmpinst->getOperand(0))) {
            auto *conststrip = stripConstCastExpr(constop);
            auto *constnp = llvm::dyn_cast<llvm::ConstantPointerNull>(conststrip);
            auto *constint = llvm::dyn_cast<llvm::ConstantInt>(conststrip);
            if (constnp) 
                return true;
            if (constint && constint->isZero())
                return true;
        }
        else if (auto constop = llvm::dyn_cast<llvm::Constant>(icmpinst->getOperand(1))) {
            auto *conststrip = stripConstCastExpr(constop);
            auto *constnp = llvm::dyn_cast<llvm::ConstantPointerNull>(conststrip);
            auto *constint = llvm::dyn_cast<llvm::ConstantInt>(conststrip);
            if (constnp) 
                return true;
            if (constint && constint->isZero())
                return true;
        }
    }
    return false;
}

llvm::BasicBlock* FreeSiteAnalysis::findTargetBasicBlock(llvm::ICmpInst *icmpinst) {
    std::deque<std::pair<llvm::Value *, bool>> pqueue;
    std::unordered_set<llvm::Value *> checked;
    pqueue.push_back(std::make_pair(icmpinst, false));
    while (!pqueue.empty()) {
        llvm::Value *curval = pqueue.front().first;
        checked.insert(curval);
        bool curcond = pqueue.front().second;
        pqueue.pop_front();
        for (auto uiter = curval->use_begin(); uiter != curval->use_end(); ++uiter) {
            auto *u = uiter->getUser();
            if (checked.find(u) != checked.end())
                continue;
            if (auto *bri = llvm::dyn_cast<llvm::BranchInst>(u)) {
                if (curcond)
                    return bri->getSuccessor(0);
                else
                    return bri->getSuccessor(1);
            }
            else if (auto *icmpi = llvm::dyn_cast<llvm::ICmpInst>(u)) {
                if (isIntegerCheckICmp(icmpi, 0, llvm::CmpInst::Predicate::ICMP_EQ))
                    pqueue.push_back(std::make_pair(u, !curcond));
                else
                    pqueue.push_back(std::make_pair(u, curcond));
            }
            else
                pqueue.push_back(std::make_pair(u, curcond));
        }
    }
    return nullptr;
}

const std::map<llvm::Function *, llvm::CallInst *> &FreeSiteAnalysis::getFreeSites() {
    return _freesites_;
}

bool FreeSiteAnalysis::isVisited(llvm::Function *function) {
    if (_visitedfunc_.find(function) != _visitedfunc_.end())
        return true;
    return false;
}

bool FreeSiteAnalysis::allowNext(SearchTask &st) {
    auto &rp = st.reference_paths;
    auto *func = rp.getFunction();
    if (func->isVarArg() || isSyscall(func) || isInterruptHandler(func))
        return false;
    if (rp.isLeakedToGlobal())
        return false;
    if (st.cur_hop >= _hoplimit_)
        return false;
    return true;
}

llvm::PostDominatorTree *FreeSiteAnalysis::createReachablePDT(llvm::Function *function) {
    _mutex_.lock();
    llvm::PostDominatorTree *pdt = nullptr;
    std::vector<llvm::BasicBlock *> unreachable_bbs;
    auto *orig_entry = &function->getEntryBlock();
    auto *sentry = llvm::BasicBlock::Create(function->getContext());
    if (_functopdt_.find(function) != _functopdt_.end()) {
        pdt = _functopdt_[function];
        goto ret;
    }
    for (auto &bb : *function) {
        if (bb.getTerminator() && llvm::isa<llvm::UnreachableInst>(bb.getTerminator()))
            unreachable_bbs.push_back(&bb);
    }
    sentry->insertInto(function, orig_entry);
    for (auto &ubb : unreachable_bbs) {
        ubb->replaceAllUsesWith(orig_entry);
    }
    pdt = new llvm::PostDominatorTree(*function);
    _functopdt_.insert(std::make_pair(function, pdt));
    ret:
    _mutex_.unlock();
    return pdt;
}

FreeSiteAnalysis::~FreeSiteAnalysis() {
}