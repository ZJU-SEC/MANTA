#pragma once
#include "Utils.h"

bool testAllocatorCollector(llvm::Module *);
bool testChargeFuncCollector(llvm::Module *);
bool testFlagAnalysis(llvm::Module *);
bool testReferencePaths(llvm::Module *);
bool testPexCallGraph(llvm::Module *);
bool testFreeSiteAnalysis(llvm::Module *);
bool testFindSyscallEntry(llvm::Module *);
bool testPageCounterAnalysis(llvm::Module *);
bool testMemcgInterfaceCollector(llvm::Module *);
bool testFreeInterfaceCollector(llvm::Module *);
bool testDuplicateAnalysis(llvm::Module *);
bool testAll(llvm::Module *, llvm::raw_ostream &);