#include "Utils.h"
#include "PexCallGraph.h"
extern PexCallGraph gCallGraph;

std::map<std::string, llvm::StructType*> nameToType;

std::string get_prefix(llvm::StructType *st) {
	std::string Name = st->getName().str();
	size_t DotPos = Name.find_last_of('.');
	return (DotPos == 0 || DotPos == std::string::npos || Name.back() == '.' ||
			!isdigit(static_cast<unsigned char>(Name[DotPos + 1])))
				? Name
				: Name.substr(0, DotPos);
}

llvm::Value *stripConstCastExpr(llvm::Value *V) {
	llvm::Value *v = V;
	assert(v);
	while(auto cexpr = llvm::dyn_cast<llvm::ConstantExpr>(v)){
		if (llvm::Instruction::CastOpsBegin <= cexpr->getOpcode() && cexpr->getOpcode() < llvm::Instruction::CastOpsEnd)
			v = cexpr->getOperand(0);
		else break;
	}
	return v;
}

llvm::Value *stripAllConstExpr(llvm::Value *V) {
	llvm::Value *v = V;
	assert(v);
	while(auto cexpr = llvm::dyn_cast<llvm::ConstantExpr>(v)){
		if (llvm::Instruction::CastOpsBegin <= cexpr->getOpcode() && cexpr->getOpcode() < llvm::Instruction::CastOpsEnd)
			v = cexpr->getOperand(0);
		else if (llvm::Instruction::GetElementPtr == cexpr->getOpcode())
			v = cexpr->getOperand(0);
		else break;
	}
	return v;
}

std::vector<llvm::ReturnInst *> getReturnInsts(llvm::Function *f) {
  	std::vector<llvm::ReturnInst *> insts;
  	for (llvm::BasicBlock &bb : f->getBasicBlockList()) {
		llvm::Instruction *i = bb.getTerminator();
      	if (auto retinst = llvm::dyn_cast<llvm::ReturnInst>(i))
        	insts.push_back(retinst);
      	/*
      	if (llvm::isa<llvm::UnreachableInst>(i))
        	insts.push_back(i);
      	*/
	}
  	return insts;
}

llvm::Function *getCallTarget(llvm::CallInst *call)
{
  	llvm::Function *f = call->getCalledFunction();
  	if (!f) {
      	f = llvm::dyn_cast<llvm::Function>(call->getCalledOperand()->stripPointerCastsAndAliases());
    }
  	return f;
}

llvm::StructType *getTypeByName(llvm::Module *M, std::string &name) {
	if (nameToType.empty()) {
		auto sttylist = M->getIdentifiedStructTypes();
		for (auto stty : sttylist) {
			if (stty->hasName()) {
				nameToType.insert(std::make_pair(stty->getName().str(), stty));
			}
		}
	}
	
	auto iter = nameToType.find(name);
	if (iter != nameToType.end())
		return iter->second;
	return nullptr;
}

llvm::StructType *getTypeByName(llvm::Module *M, std::string &&name) {
	if (nameToType.empty()) {
		auto sttylist = M->getIdentifiedStructTypes();
		for (auto stty : sttylist) {
			if (stty->hasName()) {
				nameToType.insert(std::make_pair(stty->getName().str(), stty));
			}
		}
	}
	
	auto iter = nameToType.find(name);
	if (iter != nameToType.end())
		return iter->second;
	return nullptr;
}

// std::vector<int> get_indices(llvm::GetElementPtrInst *gep)
// {
//   std::vector<int> indices;
//   for (llvm::Value *v : gep->indices())
//     {
//       if (auto c = llvm::dyn_cast<llvm::ConstantInt>(v))
//         {
//           indices.push_back(c->getSExtValue());
//         }
//       else
//         {
//           indices.push_back(0);
//         }
//     }
//   return indices;
// }

/* handle FuncName.Number */
std::string to_function_name(std::string llvm_name) {
  	size_t dot;
 	dot = llvm_name.find_first_of('.');
  	return llvm_name.substr(0, dot);
}

/* handle StructName.Number */
std::string to_struct_name(std::string llvm_name) {
	size_t dot_first, dot_last;
	dot_first = llvm_name.find_first_of('.');
	dot_last = llvm_name.find_last_of('.');
	if (dot_first == dot_last)
		return llvm_name;
	else
		return llvm_name.substr(0, dot_last);
}

bool isFunctionPointerType(llvm::Value *v) {
	llvm::Type *ty = v->getType();
    return ty->isPointerTy() && ty->getPointerElementType()->isFunctionTy();
}

bool isSyscall(llvm::Function *F) {
	const char *const arch_prefixes[] = {"__ia32", "__ia32", "__x32", "__x64", "__arm64"};
	std::string name = F->getName().str();
	for (int i = 0; i < sizeof(arch_prefixes) / sizeof(const char *); i++) {
	    std::string prefix_sys = std::string(arch_prefixes[i]) + "_sys_";
	    std::string prefix_compat_sys = std::string(arch_prefixes[i]) + "_compat_sys_";
	    if (name.rfind(prefix_sys, 0) == 0 || name.rfind(prefix_compat_sys, 0) == 0) {
			if (name.find("reboot") != name.npos)
				return false;
			return true;
		}
	}
	return false;
}

bool isInterruptHandler(llvm::Function *F) {
	return false;
}

bool isIndirectThreadFunc(llvm::Function *F) {
	// auto name = F->getName().str();
	// if (name == "worker_thread" || name == "__do_softirq")
	// 	return true;
	return false;
}


bool typeJudger::isTwoStructTyEqual(llvm::Type *ty_a, llvm::Type *ty_b) {
	if(ty_a->isStructTy() && ty_b->isStructTy()) {
		llvm::StructType* st_a = llvm::dyn_cast<llvm::StructType>(ty_a);
		llvm::StructType* st_b = llvm::dyn_cast<llvm::StructType>(ty_b);

		if (get_prefix(st_a) == get_prefix(st_b)) {
			return true;
		}
	}
	return false;
}

void print_func_vec(std::vector<llvm::Function*> &vec) {
	for(auto it : vec) {
		llvm::errs() << it->getName() << "--";
	}
	llvm::errs() << "\n";
}

void __recursive_check_syscall(int max_hop, int hop, llvm::Function* f, std::vector<llvm::Function*> vec) {
	if(hop > max_hop) {
		return;
	}

	vec.push_back(f);

	if(isSyscall(f)) {
		llvm::errs() << "find syscall chain:\n";
		print_func_vec(vec);
	} else {
		PexCallGraph::CGNode *temp_node = gCallGraph.getNode(f);
		for(auto it : temp_node->callers) {
			__recursive_check_syscall(max_hop, hop+1, it.first->f, vec);
		}
	}

	vec.pop_back();
}

void backtrace_syscall_and_print(int hop, llvm::Function* f) {
	__recursive_check_syscall(hop, 0, f, std::vector<llvm::Function*>());
}

void print_debugloc(llvm::Instruction *instruction, llvm::raw_ostream &os) {
	os << "{";
	if (instruction->getDebugLoc()) {
		instruction->getDebugLoc().print(os);
	}
	else
		os << "NF";
	os << "}";
}

llvm::DebugLoc getOuterDebugLoc(const llvm::DebugLoc &loc) {
	llvm::DebugLoc curloc = loc;
	while (curloc.getInlinedAt() != nullptr) {
		curloc = curloc.getInlinedAt();
	}
	return curloc;
}