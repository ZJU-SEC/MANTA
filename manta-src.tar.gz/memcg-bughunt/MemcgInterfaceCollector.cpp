#include "MemcgInterfaceCollector.h"
#include "ReferencePaths.h"
#include "PexCallGraph.h"

extern PexCallGraph gCallGraph;

bool MemcgInterfaceCollector::collectSeed() {
    auto pgc_cancel = _module_->getFunction("page_counter_cancel");
    auto pgc_charge = _module_->getFunction("page_counter_charge");
    auto pgc_try_charge = _module_->getFunction("page_counter_try_charge");
    _charge_seed_ = {pgc_charge, pgc_try_charge};
    _uncharge_seed_ = {pgc_cancel};
    return true;
}


std::set<llvm::Function*> MemcgInterfaceCollector::collectCharge() {
    _visited_funcs_.clear();
    for (auto func : _charge_seed_) {
        dfsWalk(func, 0, _charge_interfaces_);
    }
    return _charge_interfaces_;
}

std::set<llvm::Function*> MemcgInterfaceCollector::collectUncharge() {
    for (auto func : _uncharge_seed_) {
        dfsWalk(func, 0, _uncharge_interfaces_);
    }
    return _uncharge_interfaces_;
}

std::map<llvm::Function*, int> MemcgInterfaceCollector::generateChargeSummary(int type) {
    std::map<llvm::Function*, int> result;
    std::vector<llvm::Function*> charge_ifs;
    _visited_funcs_.clear();
    // only support UMEM currently
    // only support functions like
    // [type] charge_if(struct page *to_charge, ...)
    // plan to add functions
    // [type] charge_if(struct X *to_charge, ...) where X contains struct page* to be charged
    switch(type) {
        case UMEM:
        genSummary(_module_->getFunction("mem_cgroup_charge"), _module_->getFunction("mem_cgroup_charge")->getArg(0), UMEM, result);
        break;
        case SOCKET:
        genSummary(_module_->getFunction("__sk_mem_raise_allocated"), _module_->getFunction("__sk_mem_raise_allocated")->getArg(0), SOCKET, result);
        genSummary(_module_->getFunction("sk_forced_mem_schedule"), _module_->getFunction("sk_forced_mem_schedule")->getArg(0), SOCKET, result);
        break;
        default:
        return {};
    }
    return result;
}

std::map<llvm::Function*, int> MemcgInterfaceCollector::generateUnchargeSummary(int type) {
    std::map<llvm::Function*, int> result;
    std::vector<llvm::Function*> uncharge_ifs;
    _visited_funcs_.clear();
    switch(type) {
        case UMEM:
        break;
        default:
        return {};
    }
    return result;
}

bool MemcgInterfaceCollector::genSummary(llvm::Function *function, llvm::Value *target_val, int type, std::map<llvm::Function*, int> &summary) {
    auto callsites = gCallGraph.findCallSites(function);
    int pidx = getSrcParamIndex(function, target_val, type);
    if (_visited_funcs_.count(function) || pidx == -1)
        return 0;
    _visited_funcs_.insert(function);
    summary.insert(std::make_pair(function, pidx));
    for (auto callsite : callsites) {
        auto caller_func = callsite->getFunction();
        genSummary(caller_func, callsite->getArgOperand(pidx), type, summary);
    }
    return 1;
}

int MemcgInterfaceCollector::getSrcParamIndex(llvm::Function *function, llvm::Value *target_val, int type) {
    ReferencePaths rp(function);
    rp.addPath(target_val, {0});
    auto args = rp.getRelatedArguments();
    for (auto *arg : args) {
        auto ele_ty = arg->getType();
        if (ele_ty->isPointerTy())
            ele_ty = ele_ty->getPointerElementType();
        if (auto *stty = llvm::dyn_cast<llvm::StructType>(ele_ty)) {
            if (stty->hasName() && type == UMEM && (
              to_struct_name(stty->getName().str()) == "struct.page")) {
                return arg->getArgNo();
            }
            if (stty->hasName() && type == SOCKET && (
              to_struct_name(stty->getName().str()) == "struct.sock")) {
                return arg->getArgNo();
            }
        }
    }
    return -1;
}

bool MemcgInterfaceCollector::dfsWalk(llvm::Function *function, int cur_hop, std::set<llvm::Function*> &interfaces) {
    if (cur_hop > 3)
        return false;
    if (_visited_funcs_.count(function))
        return false;
    _visited_funcs_.insert(function);
    auto kind = getKind(function);
    emitNode(function, kind);
    if (kind == FunctionKind::INTERFACE) {
        interfaces.insert(function);
    }
    auto callsites = gCallGraph.findCallSites(function);
    for (auto callsite : callsites) {
        auto caller_func = callsite->getFunction();
        emitNode(caller_func, getKind(caller_func));
        emitEdge(caller_func, function);
        dfsWalk(caller_func, cur_hop + 1, interfaces);
    }
    return true;
}

MemcgInterfaceCollector::FunctionKind MemcgInterfaceCollector::getKind(llvm::Function *function) {
    auto callsites = gCallGraph.findCallSites(function);
    auto dbg_scope = llvm::dyn_cast<llvm::DIScope>(function->getSubprogram());
    auto filename = dbg_scope->getFilename().str();
    if (filename.find("memcontrol.c") == filename.npos && filename.find("page_counter.c") == filename.npos && filename.find("hugetlb_cgroup.c") == filename.npos)
        return FunctionKind::OUTER;

    for (auto callsite : callsites) {
        auto dbg_scope = llvm::dyn_cast<llvm::DIScope>(getOuterDebugLoc(callsite->getDebugLoc()).getScope());
        auto filename = dbg_scope->getFilename().str();
        if (filename.find("memcontrol.c") == filename.npos && filename.find("page_counter.c") == filename.npos && filename.find("hugetlb_cgroup.c") == filename.npos) {
            return FunctionKind::INTERFACE;
        }
    }
    return FunctionKind::INNER;
}

bool MemcgInterfaceCollector::emitNode(llvm::Function *node, FunctionKind fk) {
    switch(fk) {
    case FunctionKind::INNER:
        _node_set_.insert("  " 
                + to_function_name(node->getName().str()) 
                + " [label=\"" 
                + to_function_name(node->getName().str()) 
                + "\" style=filled shape=circle]\n"
            );
        break;
    case FunctionKind::INTERFACE:
        _node_set_.insert("  " 
                + to_function_name(node->getName().str()) 
                + " [label=\"" 
                + to_function_name(node->getName().str()) 
                + "\" style=filled shape=doublecircle]\n"
            );
        break;
    case FunctionKind::OUTER:
        _node_set_.insert("  " 
                + to_function_name(node->getName().str()) 
                + " [label=\"" 
                + to_function_name(node->getName().str()) 
                + "\" style=filled shape=rectangle]\n"
            );
        break;
    }
    return true;
}

bool MemcgInterfaceCollector::emitEdge(llvm::Function *caller, llvm::Function *callee) {
    _edge_set_.insert(
                "  " 
                + to_function_name(caller->getName().str())
                + " -> "
                + to_function_name(callee->getName().str())
                + "\n"
            );
    return true;
}

bool MemcgInterfaceCollector::printGraph(llvm::raw_ostream &os) {
    os << "digraph{\n";
    for(auto it : _node_set_) {
        os << it;
    }
    for(auto it : _edge_set_) {
        os << it;
    }
    os << "}\n";
    return true;
} 

