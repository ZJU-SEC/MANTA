#include "ReferencePaths.h"
#include "PexCallGraph.h"
#include "AllocatorCollector.h"

bool ReferencePaths::isLeakedToGlobal() {
    return _leakedToGlobal_;
}

const std::vector<llvm::CallInst *> &ReferencePaths::getRelatedCalls() {
    return _relatedCalls_;
}

const std::vector<llvm::ReturnInst *> &ReferencePaths::getRelatedReturns() {
    return _relatedReturns_;
}

const std::vector<llvm::Argument *> &ReferencePaths::getRelatedArguments() {
    return _relatedArguments_;
}

bool ReferencePaths::addPath(llvm::Value *value, Path &path){
    updateData(value, path);
    update();
    return true;
}

bool ReferencePaths::addPath(llvm::Value *value, Path &&path){
    updateData(value, path);
    update();
    return true;
}

ReferencePaths::Path ReferencePaths::getPath(llvm::Value *value) {
    auto iter = _result_.find(value);
    if (iter != _result_.end())
        return iter->second;
    return {};
}

bool ReferencePaths::update() {
    while (_pqueue_.size()) {
        llvm::Value *v = _pqueue_.front().first;
        Path p = _pqueue_.front().second;
        updateForDef(v, p);
        updateForUse(v, p);
        _pqueue_.pop_front();
    }
    return true;
}

bool ReferencePaths::updateForDef(llvm::Value *value, const Path &path) {
    // mostly a global variable or constantexpr of global variable
    // we do not analyze global variables
    if (auto *ci = llvm::dyn_cast<llvm::CastInst>(value)) {
        auto *op = ci->getOperand(0);
        updateData(op, path);
    }
    else if (auto *gepi = llvm::dyn_cast<llvm::GetElementPtrInst>(value)) {
        auto *op = gepi->getPointerOperand();
        Path p = path;
        llvm::APInt offset_ap = llvm::APInt::getNullValue(64);
        if (gepi->accumulateConstantOffset(gepi->getModule()->getDataLayout(), offset_ap)) {
            p.front() = p.front() + offset_ap.getSExtValue();
            updateData(op, p);
        }
        // todo: handle offsets that are not constant
        else {

        }
    }
    else if (auto *phi = llvm::dyn_cast<llvm::PHINode>(value)) {
        for (unsigned i = 0; i < phi->getNumIncomingValues(); ++i) {
            auto *op = phi->getIncomingValue(i);
            updateData(op, path);
        }
    }
    else if (auto *si = llvm::dyn_cast<llvm::SelectInst>(value)) {
        auto *optrue = si->getTrueValue();
        auto *opfalse = si->getFalseValue();
        updateData(optrue, path);
        updateData(opfalse, path);
    }
    else if (auto *ldi = llvm::dyn_cast<llvm::LoadInst>(value)) {
        auto *op = ldi->getOperand(0);
        Path p = path;
        p.push_front(0);
        updateData(op, p);
    }
    else if (auto *ci = llvm::dyn_cast<llvm::CallInst>(value)) {
        //todo : add to related call for more sound analysis
    }
    else if (auto *arg = llvm::dyn_cast<llvm::Argument>(value)) {
        addElementNodup(_relatedArguments_, arg);
    }
    return true;
}

bool ReferencePaths::updateForUse(llvm::Value *value, const Path &path) {
    for (auto uit = value->use_begin(); uit != value->use_end(); ++uit) {
        auto *userval = uit->getUser();
        if (auto *ci = llvm::dyn_cast<llvm::CastInst>(userval)) {
            updateData(ci, path);
        }
        else if (auto *gepi = llvm::dyn_cast<llvm::GetElementPtrInst>(userval)) {
            Path p = path;
            // long &curoffset = p.front();
            llvm::APInt offset_ap = llvm::APInt::getNullValue(64);
            if (gepi->accumulateConstantOffset(gepi->getModule()->getDataLayout(), offset_ap)) {
                p.front() = p.front() - offset_ap.getSExtValue();
                updateData(gepi, p);
            }
            // todo: handle offsets that are not constant
            else {

            }
        }
        else if (auto *phi = llvm::dyn_cast<llvm::PHINode>(userval)) {
            updateData(phi, path);
        }
        else if (auto *si = llvm::dyn_cast<llvm::SelectInst>(userval)) {
            updateData(si, path);
        }
        else if (auto *ldi = llvm::dyn_cast<llvm::LoadInst>(userval)) {
            Path p = path;
            if (p.front() == 0) {
                p.pop_front();
                updateData(ldi, p);
            }
        }
        else if (auto *stri = llvm::dyn_cast<llvm::StoreInst>(userval)) {
            if (stri->getOperand(0) == value) {
                Path p = path;
                p.push_front(0);
                updateData(stri->getOperand(1), p);
            }
            // else {
            //     Path p = path;
            //     if (p.front() == 0) {
            //         p.pop_front();
            //         updateData(stri->getOperand(0), p);
            //     }
            // }
        }
        else if (auto *ci = llvm::dyn_cast<llvm::CallInst>(userval)) {
            addElementNodup(_relatedCalls_, ci);
        }
        else if (auto *reti = llvm::dyn_cast<llvm::ReturnInst>(userval)) {
            addElementNodup(_relatedReturns_, reti);
        }
    }
    return true;
}

inline void ReferencePaths::updateData(llvm::Value *value, const Path &path) {
    if (llvm::isa<llvm::Constant>(value)) {
        if (llvm::isa<llvm::GlobalValue>(stripAllConstExpr(value)))
            _leakedToGlobal_ = true;
    }
    else if (path.size()){
        auto it = _result_.find(value);
        if (it == _result_.end()) {
            _pqueue_.push_back(std::make_pair(value, path));
            _result_.insert(std::make_pair(value, path));
        }
    }   
}

void ReferencePaths::print(llvm::raw_ostream &stream) {
    for (auto &item : _result_) {
        stream << *item.first << "\n its path is: ";
        for (auto num : item.second) {
            stream << num << " ";
        }
        stream << "\n";
    }
}

llvm::Function *ReferencePaths::getFunction() {
    return _function_;
}