#include "BugHuntPass.h"
#include "UnitTest.h"
#include "gatlin_idcs.h"
#include "AllocatorCollector.h"
#include "MemcgInterfaceCollector.h"
#include "FlagAnalysis.h"
#include "ReferencePaths.h"
#include "PexCallGraph.h"
#include "FreeSiteAnalysis.h"
#include "sym/Test.h"



extern PexCallGraph gCallGraph;
char BugHuntPass::ID = 0;

std::unordered_set<std::string> BugHuntPass::_excluded_allocator_ = {
    "pagecache_get_page"
};
std::unordered_set<std::string> BugHuntPass::_excluded_caller_ = {
    "__alloc_skb", "skb_copy_ubufs", "pskb_expand_head", "skb_page_frag_refill", "do_fcntl_add_lease", "fcntl_setlk", "fcntl_getlk", "posix_lock_inode", "do_sys_poll",
    "__se_sys_getcwd", "lsm_cred_alloc", "kcalloc", "bpf_prepare_filter", "cmsghdr_from_user_compat_to_kern", "____sys_sendmsg", "memcg_alloc_page_obj_cgroups", "__se_sys_io_uring_enter","get_callchain_buffers", "memdup_user_nul", "radix_tree_node_alloc", "avc_xperms_decision_alloc", "avc_xperms_populate", "disk_expand_part_tbl", "io_submit_sqes", "ioctx_alloc", "dup_userfaultfd", "copy_fs_struct", "mpol_set_shared_policy", "kernel_mbind", "inherit_event", "find_get_context", "prepare_creds", "vm_area_alloc", "dup_mm", "copy_process", "kmem_cache_open", "add_partition", "ebitmap_set_bit", "kzalloc", "ip_options_get", "copy_process", "ioctx_alloc", "process_vm_rw", "get_callchain_buffers", "bpf_prog_array_alloc", "alloc_chunk", "groups_alloc", "kmem_cache_alloc_bulk", "__se_sys_memfd_create", "nf_queue", "reuseport_alloc", "uprobe_copy_process", "copy_verifier_state", "bpf_iter_link_attach", "do_check_common","bpf_xdp_link_attach", "audit_signal_info_syscall", "__audit_sockaddr", "__audit_inode", "__audit_inode_child", "update_ref_ctr", "copy_cgroup_ns", "step_into", "__request_module", "do_madvise", "bpf_prog_offload_init", "compat_core_sys_select", "async_schedule_node_domain", "wb_get_create", "blk_add_partitions", "__do_once_done", "keyctl_read_key", "keyctl_instantiate_key_common", "keyctl_update_key", "__tlb_remove_page_size", "assoc_array_delete", "bdi_split_work_to_wbs", "nfs_pageio_add_request", "__nfs_create_request", "xfrm_state_find", "io_submit_one", "__kmem_cache_alias", "dup_fd", "alternatives_smp_module_add", "find_css_set", "mm_alloc", "btf_new_fd", "alloc_huge_page_vma", "dup_task_struct", "io_prep_async_work", "io_issue_sqe", "io_arm_poll_handler", "io_req_defer", "__kernfs_setattr", "kclist_add_private", "semctl_main", "do_semtimedop", "audit_log_exit", "ida_alloc_range", "push_pipe", "kobject_create_and_add", "__alloc_reserved_percpu", "security_task_alloc", "vmap", "vmalloc"
};

bool BugHuntPass::runOnModule(llvm::Module &M) {
    // test symbolic execution
    // TestPass testpass;
    // std::vector<pair<Function*,CallInst*>> callchain;
    // llvm::Function *targetFunc = nullptr;
    // for (auto &func : M){
    //   if (func.getName()=="__x64_sys_setns"){
    //     targetFunc=&func;
    //     break;
    //   }
    // }
    // assert(targetFunc!= nullptr);
    // // std::vector<std::string> funcNames{"do_mq_timedsend","load_msg","security_msg_msg_alloc"};
    // std::vector<std::string> funcNames{"__se_sys_setns", "create_new_namespaces", "copy_pid_ns"};

    // int i=0;
    // llvm::Function* func=targetFunc;
    // bool changed;
    // do{
    //   changed=false;
    //   for (auto it=inst_begin(func);it!=inst_end(func);++it){
    //     if (auto *ci=dyn_cast<CallInst>(&*it)){
    //       if (ci->getCalledFunction()!= nullptr && ci->getCalledFunction()->getName()==funcNames[i]){
    //         //outs()<<*ci<<"\n";
    //         callchain.emplace_back(func,ci);
    //         func=ci->getCalledFunction();
    //         changed=true;
    //         i++;
    //         break;
    //       }
    //     }
    //   }
    // } while (changed && i<funcNames.size());
    // testpass.inputCallChain(callchain);
    // testpass.runOnModule(M);
    /////////////////////////////////////////////////////////////
    llvm::errs() << "MANTA analyzer for Linux missing-account bugs.\n";
    _module_ = &M;
    _allocfuncs_ = new AllocatorCollector(M);
    // llvm::errs() << "Allocator list:\n";
    // for (auto &af : _allocfuncs_->getAllocateFunctions()) {
    //     llvm::errs() << af->getName().str() << "\n";
    // }
    ////////////////////////////////////
    //          UNIT TEST             //
    ////////////////////////////////////
    
    // testPexCallGraph(_module_);
	// testAllocatorCollector(_module_);
	// testFlagAnalysis(_module_);
	// testFindSyscallEntry(_module_);
	// testReferencePaths(_module_);
	// testFreeSiteAnalysis(_module_);
    // testPageCounterAnalysis(_module_);
    // testMemcgInterfaceCollector(_module_);
    // testFreeInterfaceCollector(_module_);
    // testDuplicateAnalysis(_module_);
	////////////////////////////////////
    //          UNIT TEST END         //
	////////////////////////////////////
	std::error_code ec;
	llvm::raw_fd_ostream fstream("./bughunt-result.txt", ec, llvm::sys::fs::F_Text | llvm::sys::fs::F_Append);
    auto start = std::chrono::system_clock::now();
	analyze();
    generateResult(fstream);
    auto end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    std::time_t end_time = std::chrono::system_clock::to_time_t(end);
    std::cout << "finished computation at " << std::ctime(&end_time)
              << "elapsed time: " << elapsed_seconds.count() << "s\n";
    delete _allocfuncs_;
    return true;
}

void BugHuntPass::traceTaskEntry(std::vector<llvm::CallInst*> &ci_stack, std::set<std::vector<llvm::CallInst*> > &result_path, const std::map<llvm::Function*, llvm::CallInst *> &free_sites) {
    auto top_ci = ci_stack.back();
    auto top_fn = top_ci->getFunction();
    if (ci_stack.size() == 10 || free_sites.find(top_fn) != free_sites.end())
        return;
	if (top_fn == nullptr) {
		llvm::errs() << "Cannot find function holding the CallInst: " << *top_ci << "\n";
		return;
	}
	PexCallGraph::CGNode *n = gCallGraph.getNode(top_fn);
	for (auto link : n->callers) {
		llvm::CallInst *nextci = link.second->call;
        // prune
		if (std::find(ci_stack.begin(), ci_stack.end(), nextci) != ci_stack.end()) {
			continue;
		}
        else if (_allocfuncs_->isAllocator(nextci->getFunction())) {
            continue;
        }

		ci_stack.push_back(nextci);
		if (isSyscall(nextci->getFunction())) {
	    	result_path.insert(ci_stack);
		}
        else if (isInterruptHandler(nextci->getFunction())) {
            result_path.insert(ci_stack);
        }
        else if (isIndirectThreadFunc(nextci->getFunction())) {
            result_path.insert(ci_stack);
        }
		else{
	    	traceTaskEntry(ci_stack, result_path, free_sites);
		}
	  	ci_stack.pop_back();
	}
    /////////////////
    // if (n->callers.empty()) {
    //     result_path.insert(ci_stack);
    // }
    ////////////////
}

void BugHuntPass::generateResult(llvm::raw_ostream &os) {
    int num_paths = 0;
    std::vector<llvm::CallInst*> temp_ci;
    std::set<std::vector<llvm::CallInst*> > result_paths;
    std::set<std::vector<llvm::CallInst*> > result_paths_syscall;
    std::set<std::vector<llvm::CallInst*> > result_paths_ih;
    std::set<std::vector<llvm::CallInst*> > result_paths_threadfn;
    auto charged_allocs = _charged_allocs_normal_;
    charged_allocs.insert(_charged_allocs_kmem_.begin(), _charged_allocs_kmem_.end());
    // print alloc
    // for (auto *callsite : charged_allocs) {
    //     temp_ci.clear();
    //     result_paths.clear();
    //     os << "Already accounted allocation site: ";
    //     print_debugloc(callsite, os);
    //     os << "\n";
    //     os.flush();
    //     temp_ci.push_back(callsite);
    //     std::map<llvm::Function*, llvm::CallInst *> emptymap = {};
    //     traceTaskEntry(temp_ci, result_paths, emptymap);
    //     if (!result_paths.empty()) {
    //         os << "Charging paths found:\n";
    //         for (auto &path : result_paths) {
    //             for (auto &hop : path) {
    //                 os << " -> ";
    //                 print_debugloc(hop, os);
    //                 os << "@" << hop->getFunction()->getName();
    //             }
    //             os << "\n";
    //         }
    //     }
    // }

    for (auto *callsite : _uncharged_allocs_) {
        temp_ci.clear();
        result_paths.clear();
        os << "Unaccounted allocation site: ";
        print_debugloc(callsite, os);
        os << "\n";
        os.flush();
        temp_ci.push_back(callsite);
        traceTaskEntry(temp_ci, result_paths, _allocs_free_sites_[callsite]);
        num_paths += result_paths.size();
        if (!result_paths.empty()) {
            os << "Unaccounted paths found:\n";
            for (auto &path : result_paths) {
                for (auto &hop : path) {
                    os << " -> ";
                    print_debugloc(hop, os);
                    os << "@" << hop->getFunction()->getName();
                }
                os << "\n";
            }
        }
    }

    // for (auto *callsite : _unknown_allocs_) {
    //     temp_ci.clear();
    //     result_paths.clear();
    //     os << "Unknown allocation site: ";
    //     print_debugloc(callsite, os);
    //     os << "\n";
    //     os.flush();
    // }

    // os << "-----------------Split--------------------\n";
    // for (auto freesite : _allocs_free_sites_) {
    //     os << "Free sites for allocsite @ ";
    //     print_debugloc(freesite.first, os);
    //     os << "\n";
    //     for (auto item : freesite.second) {
    //         if (item.first->hasName())
    //             os << item.first->getName() << "@";
    //         print_debugloc(item.second, os);
    //         os << "\n";
    //     }
    // }
    // os << "-----------------Split--------------------\n";

    // os << "Total:\n" << "\tAccounted Normal: " << _charged_allocs_normal_.size() << "\n";
    // os << "\t Accounted kmem_cache_create: " << _charged_allocs_kmem_.size() << "\n";
    // os << "\tUnaccounted: " << _uncharged_allocs_.size() << "\n";
    // os << "\tUnaccounted paths with alloc-free window: " << num_paths << "\n";
    // os << "\tUnknown: " << _unknown_allocs_.size() << "\n";
}

void BugHuntPass::analyze() {
    int iter_times = 0;
    std::vector<WorkerFuture> async_threads;
    auto allocator_funcs = _allocfuncs_->getAllocateFunctions();
    std::set<llvm::Function*> spanned_funcs;
    int longest_cc = 0;
    for (auto *allocator_func : allocator_funcs) {
        llvm::errs() << iter_times << "/" << allocator_funcs.size() << " finished.\n";
        llvm::errs() << "current allocator is " << allocator_func->getName() << ".\n";
        ++iter_times;
        if (_excluded_allocator_.find(to_function_name(allocator_func->getName().str())) != _excluded_allocator_.end())
            continue;
        auto *allocator = _allocfuncs_->getMemAllocator(allocator_func);
        auto callsites = gCallGraph.findCallSites(allocator_func);
        for (auto *callsite : callsites) {
			if (!_allocfuncs_->isAllocator(callsite->getFunction())) {
				// flag analysis
                FlagAnalysis fa(allocator, callsite);
                auto account_type = fa.getAccountType();
                auto spf_once = fa.getSpannedFunctions();
                spanned_funcs.insert(spf_once.begin(), spf_once.end());
                longest_cc = longest_cc < fa.getLongestCallChain() ? fa.getLongestCallChain() : longest_cc;
                if (account_type == FlagAnalysis::AccountType::NORMAL) {
					_charged_allocs_normal_.insert(callsite);
                }
                else if (account_type == FlagAnalysis::AccountType::KMEM_CACHE_CREATE) {
					_charged_allocs_kmem_.insert(callsite);
                }
                else if (account_type == FlagAnalysis::AccountType::UNK) {
                    _unknown_allocs_.insert(callsite);
                }
                else if (account_type == FlagAnalysis::AccountType::NONE) {
                    if (_excluded_caller_.find(to_function_name(callsite->getFunction()->getName().str())) != _excluded_caller_.end())
                        continue;
					_uncharged_allocs_.insert(callsite);
                    auto iter = getFirstIdle(async_threads);
					if (iter == async_threads.end()) {
                        async_threads.push_back(std::async(std::launch::async, &BugHuntPass::workerThread, this, callsite));
                    }
                    else {
                        *iter = std::async(std::launch::async, &BugHuntPass::workerThread, this, callsite);
                    }
                    // workerThread(callsite);
				}
			}
		}
        // llvm::errs() << "GFP flags spanned " << spanned_funcs.size() << "functions.\n";
        // llvm::errs() << "The longest callchain length is " << longest_cc <<".\n";
	}
}

int BugHuntPass::workerThread(llvm::CallInst* allocsite) {
    FreeSiteAnalysis fsa(allocsite, _allocfuncs_);
    _mu_afs_.lock();
    _allocs_free_sites_.insert(std::make_pair(allocsite, fsa.getFreeSites()));
    _mu_afs_.unlock();
    return 0;
}

std::vector<BugHuntPass::WorkerFuture>::iterator BugHuntPass::getFirstIdle(std::vector<WorkerFuture> &tasks) {
    if (tasks.size() < MAX_NUM_THREADS)
        return tasks.end();
    while (true) {
        for (auto iter = tasks.begin(); iter != tasks.end(); ++iter) {
            if (iter->wait_for(std::chrono::milliseconds(100)) == std::future_status::ready)
                return iter;
        }
    }
}

static llvm::RegisterPass<BugHuntPass>
Z("memcg-bughunt", "Hunting bugs in kernel memcg");
