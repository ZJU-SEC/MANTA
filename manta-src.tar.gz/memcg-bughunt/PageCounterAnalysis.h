#pragma once
#include "Utils.h"

class AllocatorCollector;

class PageCounterAnalysis {
public:
    PageCounterAnalysis(llvm::Module *module, AllocatorCollector *ac):_module_(module), _collector_(ac){}
    bool checkUserCharging();
    bool checkSKBCharging();
private:
    llvm::Module *_module_;
    AllocatorCollector *_collector_;
};