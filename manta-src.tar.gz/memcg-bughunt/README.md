Check Memcg Memory Accounting
---
`memcg_check` is a tool for analyzing memory cgroup (memcg) in Linux kernel. 


# Environment
- wllvm 1.2.7
- LLVM 10.0.0
- Linux 5.3.6

# How to run
## Compile Linux Kernel to LLVM IR (`vmlinux.bc`)


More details can be found in [compile Linux kernel using wllvm](http://blog.xiexun.tech/compile-linux-llvm.html) and [how to use custom optimization options](http://blog.xiexun.tech/linux-bc-custom-opt.html).

## Run LLVM Pass on `vmlinux.bc`
To compile the LLVM pass,
``` shell
mkdir build
cd build
cmake ../
make
```

And then, run the pass on the `vmlinux.bc` we compiled before by
``` shell
opt -analyze -load=./libmemcg_bughunt.so -memcg-bughunt -o /dev/null path/to/vmlinux.bc 2>&1 > result.txt
```

# Result


# Implementation


# Files
- call_graph.cpp: constructs call graph
- load_store.cpp: handles load and store instructions
- flag.cpp: analyzes possible values of a flag
- kmem_cache.cpp: analyzes whether a `kmem_cache` is always charged
- charged.cpp: handles special memcg charging cases (user memory)
- utilities.cpp: several useful functions
- memcg_check.cpp: initializes function lists and outputs result

# TODO
