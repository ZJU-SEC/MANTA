#include "AllocatorCollector.h"
#include "PexCallGraph.h"
#include "llvm/IR/DebugLoc.h"

extern PexCallGraph gCallGraph;

// #define DEBUG_ALLOCATOR
// #define ARG_DEBUG
// #define TRY_NO_RETURN true
// #define DEBUG_ACCOUNT_BIT
#define DEBUG_EXPORTED
#define __GFP_ACCOUNT 0x400000

#define CHARGE_BIT 22

#define EXPORT_PREFIX "__addressable_"

#define FALSE_RETURN 6666

#define MAX_HOP 10

static std::set<llvm::Function *> buddy_API;
std::set<llvm::Function*> exported_function_set;

struct index_value
{
    unsigned index;
    unsigned long value;
};

static std::set<std::string> char_ptr_ret_list {
	"memory_stat_format",
	"create_unique_id",
	"kstrdup",
	"kstrdup_const",
	"kstrndup",
	"kmemdup_nul",
	"strndup_user",
	"cache_name",
	"cache_name",
	"zpool_get_type",
	"shmem_format_huge",
	"shmem_get_link",
	"kstrdup_quotable",
	"kstrdup_quotable_cmdline",
	"kstrdup_quotable_file",
	"kobject_get_path",
	"kvasprintf",
	"kvasprintf_const",
	"kasprintf",
	"nla_strdup",
	"put_dec_trunc8",
	"put_dec_full8",
	"put_dec",
	"put_dec",
	"number",
	"special_hex_number",
	"widen_string",
	"string_nocheck",
	"error_string",
	"check_pointer_msg",
	"string",
	"pointer_string",
	"ptr_to_id",
	"restricted_pointer",
	"dentry_name",
	"bdev_name",
	"symbol_string",
	"resource_string",
	"hex_string",
	"bitmap_string",
	"bitmap_list_string",
	"mac_address_string",
	"ip4_string",
	"ip6_compressed_string",
	"ip6_string",
	"ip6_addr_string",
	"ip4_addr_string",
	"ip6_addr_string_sa",
	"ip4_addr_string_sa",
	"ip_addr_string",
	"escaped_string",
	"va_format",
	"uuid_string",
	"netdev_bits",
	"address_val",
	"date_str",
	"time_str",
	"rtc_str",
	"time_and_date",
	"clock",
	"format_flags",
	"flags_string",
	"device_node_name_for_depth",
	"device_node_gen_full_name",
	"device_node_string",
	"kobject_string",
	"pointer",
	"test_case_str",
	"bitmap_getnum",
	"bitmap_find_region",
	"bitmap_parse_region",
	"*argv_split",
	"scsi_dh_attached_handler_name",
	"crypto_skcipher_driver_name",
	"crypto_ahash_alg_name",
	"crypto_ahash_driver_name",
	"crypto_shash_alg_name",
	"crypto_shash_driver_name",
	"state_to_string",
	"wiphy_name",
	"ieee80211_get_tx_led_name",
	"ieee80211_get_rx_led_name",
	"ieee80211_get_assoc_led_name",
	"ieee80211_get_radio_led_name",
	"tcp_ca_get_name_by_key",
	"nfc_device_name",
	"crypto_tfm_alg_name",
	"crypto_tfm_alg_driver_name",
	"crypto_blkcipher_name",
	"crypto_comp_name",
	"ceph_extract_encoded_string",
	"dma_chan_name",
	"strstrip",
	"kbasename",
	"strncpy",
	"strcat",
	"strncat",
	"strcpy",
	"hex_byte_pack",
	"hex_byte_pack_upper",
	"skb_end_pointer",
	"skb_end_pointer",
	"skb_tail_pointer",
	"skb_tail_pointer",
	"skb_inner_transport_header",
	"skb_inner_network_header",
	"skb_inner_mac_header",
	"skb_transport_header",
	"skb_network_header",
	"skb_mac_header",
	"skb_checksum_start",
	"blkg_path",
	"dev_name",
	"fscrypt_get_symlink",
	"kobject_name",
	"xattr_prefix",
	"kernel_load_data_id_str",
	"CONCAT_",
	"bvec_kmap_irq",
	"bvec_kmap_irq",
	"kernel_read_file_id_str",
	"snd_pcm_stream_str",
	"blkg_dev_name",
	"blk_op_str",
	"nfs_server_fscache_state",
	"nfs_server_fscache_state",
	"nfs_devname",
	"ubifs_get_link",
	"btrfs_ref_to_path",
	"qgroup_rsv_type_str",
	"btrfs_stripe_dev_uuid",
	"btrfs_stripe_dev_uuid_nr",
	"btrfs_super_csum_name",
	"xattr_full_name",
	"ext4_decode_error",
	"get_qf_name",
	"token2str",
	"hvc_iucv_parse_filter",
	"iscsi_get_ipaddress_state_name",
	"iscsi_get_router_state_name",
	"iscsi_session_state_name",
	"iscsi_get_discovery_parent_name",
	"iscsi_get_port_speed_name",
	"iscsi_get_port_state_name",
	"scsi_debug_info",
	"scsi_alloc_sense_buffer",
	"scsi_dh_attached_handler_name",
	"st_incompatible",
	"tape_name",
	"mdname",
	"*realloc_argv",
	"dm_shift_arg",
	"dm_table_device_name",
	"dm_device_name",
	"cc_dma_buf_type",
	"pblk_disk_name",
	"_goya_get_event_desc",
	"transport_get_sense_buffer",
	"transport_dump_cmd_direction",
	"data_dir_name",
	"cmd_state_name",
	"target_ts_to_str",
	"target_tmf_name",
	"skd_pci_info",
	"skd_drive_state_to_str",
	"skd_skdev_state_to_str",
	"skd_skreq_state_to_str",
	"cmdname",
	"drbd_buildtag",
	"composite_default_mfr",
	"dmastr",
	"udc_ep_state",
	"udc_ep_status",
	"trx_mode",
	"gr_ep0state_string",
	"type_string",
	"type_string",
	"buf_state_string",
	"dma_mode_string",
	"usb_get_gadget_udc_name",
	"decode_ep0_state",
	"usb_cache_string",
	"usb_devnode",
	"xhci_trb_comp_code_string",
	"xhci_trb_type_string",
	"xhci_ring_type_string",
	"xhci_slot_state_string",
	"xhci_decode_trb",
	"xhci_decode_ctrl_ctx",
	"xhci_decode_slot_context",
	"xhci_portsc_link_state_string",
	"xhci_decode_portsc",
	"xhci_ep_state_string",
	"xhci_ep_type_string",
	"xhci_decode_ep_context",
	"hcfs2string",
	"dbg_port_buf",
	"rh_state_string",
	"decode_ep0stage",
	"i915_fence_get_driver_name",
	"i915_fence_get_timeline_name",
	"rc_devnode",
	"smscore_translate_msg",
	"smscore_get_fw_filename",
	"uvc_query_name",
	"kstruprdup",
	"brcmf_fweh_event_name",
	"brcmf_fweh_event_name",
	"queue_name",
	"rs_pretty_ant",
	"rs_pretty_lq_type",
	"rs_pretty_rate",
	"ath_opmode_to_string",
	"ath_bus_type_to_string",
	"sky2_name",
	"mc_name",
	"func_name",
	"nic_name",
	"nfp_app_name",
	"nfp_app_extra_cap",
	"nfp_app_mip_name",
	"mlx5_command_str",
	"cmd_status_str",
	"deliv_status_to_str",
	"alx_speed_desc",
	"neg_adv_str",
	"srp_target_info",
	"xen_swiotlb_error",
	"visorchannel_guid_id",
	"visorchannel_id",
	"visorchannel_zoneid",
	"perf_pmu_name",
	"regmap_name",
	"devm_kstrdup",
	"devm_kstrdup_const",
	"devm_kvasprintf",
	"devm_kasprintf",
	"ieee80211_get_reason_code_string",
	"ife_meta_id2name",
	"ceph_osdmap_state_str",
	"ceph_pg_pool_name_by_id",
	"ceph_msg_type_name",
	"ceph_pr_addr",
	"rpc_sockaddr2uaddr",
	"sock_prot_memory_pressure",
	"dn_addr2asc",
	"dn_state2asc",
	"reg_dfs_region_str",
	"reg_initiator_name",
	"ieee80211_scan_add_ies",
	"pep_get_sb",
	"alloc_one_pg_vec_page",
	"msg_data",
	"msg_media_addr",
	"label_modename",
	"aa_label_strn_split",
	"aa_label_str_split",
	"aa_get_str",
	"basename",
	"aa_split_fqname",
	"skipn_spaces",
	"aa_splitn_fqname",
	"aa_str_alloc",
	"security_get_initial_sid_context",
	"__bpf_address_lookup",
	"arch_vma_name",
	"kdb_strdup",
	"check_image_kernel",
	"cgroup_file_name",
};

/*
 * check if the return type of f_ptr is void*,char* (i8* in LLVM IR)
 * return true if it is, otherwise false
 */
bool ___check_ret_is_i8_ptr(llvm::Function *f_ptr)
{
    if (llvm::PointerType *pt = llvm::dyn_cast<llvm::PointerType>(f_ptr->getReturnType()))
    {
        if (llvm::IntegerType *it = llvm::dyn_cast<llvm::IntegerType>(pt->getPointerElementType()))
        {
            if (it->getBitWidth() == 8)
            {
                if(char_ptr_ret_list.find(to_function_name(f_ptr->getName().str()))==char_ptr_ret_list.end()) {
                    // this function returns the char*
                    return true;
                }
            }
        }
    }
    return false;
}

bool check_exported_name(std::string value_name) {
    if (value_name.find(EXPORT_PREFIX) == 0) {
        return true;
    }
    return false;
}

void initialize_exported_function_set(llvm::Module &M) {
    for(llvm::Module::global_iterator it=M.global_begin(); it!=M.global_end(); it++) {
        std::string name = std::string(it->getName());
        if(check_exported_name(name)) {
            // this function is expoted
            // the global must be looked like this
            // @__addressable___alloc_pages_nodemask4882 = 
            //     internal global i8* bitcast (
            //         %struct.page.125297* (i32, i32, i32, %struct.cpumask*)* @__alloc_pages_nodemask to i8*
            //     ), section ".discard.addressable", align 8, !dbg !1390301
            // so we should get its constuctor first and strip off the bitcast
            llvm::Value* f = stripConstCastExpr(it->getInitializer());
            if(llvm::isa<llvm::Function>(f)) {
                exported_function_set.insert(llvm::dyn_cast<llvm::Function>(f));
                // llvm::errs() << "find an exported function! v = " << f->getName() << "\n";
            }
        }
    }
}

/* check whether the function is exported*/
bool CheckExported(llvm::Function* f_ptr, llvm::Module* M) {
    if(exported_function_set.empty()) {
        initialize_exported_function_set(*M);
    }
    if (exported_function_set.find(f_ptr) != exported_function_set.end()) {
        return true;
    }

    return false;
}

/*
 * print debug info(location in the source code of this instruction @inst)
 */
void ___get_dbg_loc(llvm::Instruction *inst)
{
    const llvm::DebugLoc &location = inst->getDebugLoc();
    if (location)
    {
        location.print(llvm::errs());
        llvm::errs() << "\n";
    }
}

/*
 * check if the return type of f_ptr is page* (%struct.page or %struct.page.xxx in LLVM IR)
 * return true if it is, otherwise false
 */
bool ___check_ret_is_page_ptr(llvm::Function *f_ptr, llvm::Module *M)
{
    if (llvm::PointerType *pt = llvm::dyn_cast<llvm::PointerType>(f_ptr->getReturnType()))
    {
        llvm::Type *retType = pt->getPointerElementType();
        if (retType->isStructTy())
        {
            // use typeJudger to check the return value if it is struct page type
            llvm::Type *page_struct = getTypeByName(M, "struct.page");
            typeJudger tj = {M};
            if (tj.isTwoStructTyEqual(page_struct, retType))
            {
                return true;
            }
        }
    }
    return false;
}

bool MemAllocator::isExported() {
    return this->_is_exported_;
}

/*
 * check if the Value* @v is one of the Function* @f_ptr's argument
 * 
 * @return: index(>=0) for @v is an argument, its index in arg list
 *          -1         for @v is not
 */
int ___check_if_argument(llvm::Function *f_ptr, llvm::Value *v)
{
    for (int i = 0; i < f_ptr->arg_size(); i++)
    {
        if (f_ptr->getArg(i) == v)
        {
            // v and argument has the same address which means they are the same Value*
            // just return the arg index i
            return i;
        }
    }
    return -1;
}

llvm::StoreInst* ___recursive_traverse_to_find_store(llvm::Value* v, std::unordered_set<llvm::Value*> isChecked) {
    if(isChecked.find(v) != isChecked.end()) {
        return NULL;
    }

    isChecked.insert(v);

    if (llvm::isa<llvm::StoreInst>(v))
    {
        return llvm::dyn_cast<llvm::StoreInst>(v);
    }
    else if (llvm::isa<llvm::CastInst>(v)) {
        return ___recursive_traverse_to_find_store(stripConstCastExpr(v), isChecked);
    }
    return NULL;
}

std::set<llvm::Value*> ___get_all_store_from_load(llvm::LoadInst* li) {
    std::set<llvm::Value*> stored_value_set;
    for (llvm::Value* it : li->getPointerOperand()->users())
    {
        llvm::StoreInst* ret = ___recursive_traverse_to_find_store(it, std::unordered_set<llvm::Value*>());
        if(ret) {
            stored_value_set.insert(ret->getValueOperand());
        }
    }
    return stored_value_set;
}

long long ___get_gep_operand_index(llvm::GetElementPtrInst *gep, unsigned index)
{
    if (gep->getNumOperands() <= index)
    {
        return FALSE_RETURN;
    }

    if (llvm::ConstantInt *CI = llvm::dyn_cast<llvm::ConstantInt>(gep->getOperand(index)))
    {
        return CI->getZExtValue();
    }

    return FALSE_RETURN;
}

bool ___check_gep_ty(llvm::Module *M, llvm::GetElementPtrInst *gep, llvm::StringRef tyName, std::vector<index_value> &indices)
{
    llvm::Type *gep_source_ty = gep->getSourceElementType();

    if (llvm::isa<llvm::StructType>(gep_source_ty))
    {
        typeJudger tj = {M};
        llvm::Type *ty_origin = getTypeByName(M, tyName.str());

        if (tj.isTwoStructTyEqual(gep_source_ty, ty_origin))
        {
            for (auto it : indices)
            {
                unsigned long temp_value = ___get_gep_operand_index(gep, it.index);
                if (temp_value != it.value)
                {
                    return false;
                }
            }
            // check return value is page*
            if (___check_ret_is_page_ptr(gep->getFunction(), M))
            {
                // pass check
                return true;
            }
        }
    }
    return false;
}

bool ___recursive_check_if_reach_nodemask(llvm::Function* f, int hop) {
    if(f->getName().find("__alloc_pages_nodemask") != llvm::StringRef::npos) {
        return true;
    }

    if(hop > MAX_HOP) {
        return false;
    }

    bool ret = true;
    
    PexCallGraph::CGNode* temp_node = gCallGraph.getNode(f);

    for(auto it : temp_node->callers) {
        if (!___recursive_check_if_reach_nodemask(it.first->f, hop+1))
        {
            ret = false;
        }
    }

    if(!ret) {
        llvm::errs() << "hop: " << hop << " function: " << f->getName() << "\n";
    }
    return ret;
}

/*
 * ___buddy_api_init find all possible buddy API functions and 
 * store them into the static global std::set<llvm::Function*> buddy_API
 * 
 * @M: module pointer of input linux LLVM IR
 * 
 */
void ___buddy_api_init(llvm::Module *M)
{
    /*
     * When we want to get page(s) from buddy allocator, the allocator will find page(s)
     * inside the memory zone(struct zone).
     * 
     * I'm pretty confident that there are only two normal ways to get the page:
     *     1. from the zone.free_area[@oder].free_list[@migrate_type], which is a list_head
     *     2. from the zone.pageset.pcp.lists[@migrate_type], which is a list_head
     * 
     * the No.2 way is only adopt when user ask only 1 page(with the order 0), and pcp is a __per_cpu
     * field of struct zone, which means each cpu has a 1 page list for allocation
     * 
     * In LLVM IR, when we want to access the field of free_area(struct free_area) or pcp(struct per_cpu_pages),
     * it must use getelementptr instruction, and the offset must match the specific field.
     * For example:
     *     **free_area.free_list[]**
     *     %269 = getelementptr %struct.free_area, %struct.free_area* %.216.i.i, i64 0, i32 0, i64 %268
     *     **per_cpu_pages.lists[]**
     *     %18 = getelementptr %struct.per_cpu_pages, %struct.per_cpu_pages* %2, i64 0, i32 3, i64 %17
     * 
     * so the only thing we should do is check the `gep` instruction and confirm the struct type and offset
     *     1. gep, %struct.free_area, i64 0, i32 0
     *     2. gep, %struct.per_cpu_pages, i64 0, i32 3
     *     2*. gep, %struct.per_cpu_pageset, i64 0, i32 0, i32 3
     * 
     * NOTICE, follow above rule, we will find these functions:
     * 
     *         free_area_empty
     *         free_unref_page_commit
     *         free_pcppages_bulk
     *         get_page_from_free_area
     *         rmqueue_pcplist
     *         pageset_init
     * 
     * and the buddy allocate API root is `get_page_from_free_area` and `rmqueue_pcplist`
     * only these 2 functions return page*, other return void or other type. This makes sense.
     */

    // TODO: to be complete

    for (llvm::Function &f_it : M->functions())
    {
        for (llvm::BasicBlock &bb_it : f_it)
        {
            for (llvm::Instruction &ins_it : bb_it)
            {
                // for each instruction, we have to check if it is a gep inst first
                if (llvm::isa<llvm::GetElementPtrInst>(ins_it))
                {
                    // now we have to check the struct type
                    // there are only two struct type we concerned about
                    //    struct.free_area and struct.per_cpu_pages
                    llvm::GetElementPtrInst *gep = llvm::dyn_cast<llvm::GetElementPtrInst>(&ins_it);

                    // set to store the API
                    std::set<llvm::Function*> api_set;

                    // initialize check vector

                    // 1. gep, %struct.free_area, i64 0, i32 0
                    std::vector<index_value> v1;
                    v1.push_back({1, 0});
                    v1.push_back({2, 0});

                    // 2. gep, %struct.per_cpu_pages, i64 0, i32 3
                    std::vector<index_value> v2;
                    v2.push_back({1, 0});
                    v2.push_back({2, 3});

                    // 2*. gep, %struct.per_cpu_pageset, i64 0, i32 0, i32 3
                    std::vector<index_value> v3;
                    v3.push_back({1, 0});
                    v3.push_back({2, 0});
                    v3.push_back({3, 3});

                    if (___check_gep_ty(M, gep, "struct.free_area", v1))
                    {
                        // find a suitable case 1 buddy API
                        llvm::errs() << "find API 1 root: " << f_it.getName() << "\n";
                        api_set.insert(&f_it);
                    }
                    else if (___check_gep_ty(M, gep, "struct.per_cpu_pages", v2))
                    {
                        // find a suitable case 2 buddy API
                        llvm::errs() << "find API 2 root: " << f_it.getName() << "\n";
                        api_set.insert(&f_it);
                    }
                    else if (___check_gep_ty(M, gep, "struct.per_cpu_pageset", v3))
                    {
                        // find a suitable case 2 buddy API
                        llvm::errs() << "find API 2* root: " << f_it.getName() << "\n";
                        api_set.insert(&f_it);
                    }
                    
                    // go through the set and check if all functions in the set will reach
                    // `__alloc_pages_nodemask()`
                    for(llvm::Function* it : api_set) {
                        if(!___recursive_check_if_reach_nodemask(it, 0)) {
                            llvm::errs() << "this root is not pure allocator: " << it->getName() << "\n" ;
                        }
                    }
                }
            }
        }
    }
}

/*
 * this function is used for allocator collecting
 * all allocators we find is stored in the _alloctor_set_
 * 
 * Allocator Definition:
 *     1. the return type of an allocator function is `void*` or `page*`
 *     2. one of the arguments is `gfp_t gfpflags`
 * 
 * TODO:
 *     At present we cannot distinguish the char* and void*
 *     (for both of them are i8* in LLVM IR)
 */
void AllocatorCollector::__collectAllAllocators()
{
    /*
     * not complete
     * 
     * call buddy_api_init to find all possible buddy allocator API
     * and the collecting will begin from these APIs
     * 
     * all API function wiil store in the static global 
     *         std::set<llvm::Function*> buddy_API
     * 
     */
    // ___buddy_api_init(this->_module_);
    // return;

    /*
     * At present, we use __alloc_pages_nodemask()
     * as the start of the allocators backtracing
     * 
     * TODO: use a function to confirm all the possible
     *       start point(using the zone->freearea->freelist)
     */
    llvm::Function *__alloc_pages_nodemask = this->_module_->getFunction("__alloc_pages_nodemask");
    PexCallGraph::CGNode *root_allocator_node = gCallGraph.getNode(__alloc_pages_nodemask);

    // we add __alloc_pages_nodemask to the allocator set
    // TODO: we have to confirm the only entry of buddy system allocation is __alloc_pages_nodemask
    __addNewAllocator(__alloc_pages_nodemask, 0, CHARGE_BIT, RET_TYPE::PAGE_PTR);

#ifdef DEBUG
    /*
     * JUST FOR DEBUG
     */
    MemAllocator *debug_allocator = new MemAllocator(__alloc_pages_nodemask, 0, 0);
    this->_alloctor_set_.insert(debug_allocator);
    this->_function_set_.insert(__alloc_pages_nodemask);
    this->_allocator_map_.insert(std::pair<llvm::Function *, MemAllocator *>(__alloc_pages_nodemask, debug_allocator));
    return;
#endif

    // we will recursively check all callers and callers' callers and so on
    for (auto it : root_allocator_node->callers)
    {
        __recursive_checkAllocator(it.first->f, __alloc_pages_nodemask, it.second->call, std::unordered_set<llvm::Function *>());
    }

    // for mempool, the normal allocate interface function cannot be found by callgraph
    // because the ->alloc field is initialized through function like mempool_create or
    // mempool_init, so here we just add it by hand
    llvm::Function *mempool_alloc = this->_module_->getFunction("mempool_alloc");
    // PexCallGraph::CGNode *node_mempool_alloc = gCallGraph.getNode(mempool_alloc);
    __addNewAllocator(mempool_alloc, 1, CHARGE_BIT, RET_TYPE::VOID_PTR);

    // add the call relationship between 
    // PexCallGraph::CGNode *node_mempool_alloc_slab = gCallGraph.getNode(this->_module_->getFunction("mempool_alloc_slab"));
    // PexCallGraph::CGNode *node_mempool_kmalloc = gCallGraph.getNode(this->_module_->getFunction("mempool_kmalloc"));
    // PexCallGraph::CGNode *node_mempool_alloc_pages = gCallGraph.getNode(this->_module_->getFunction("mempool_alloc_pages"));

    // std::set<PexCallGraph::CGNode *> child_node_set;
    // child_node_set.insert(node_mempool_alloc_slab);
    // child_node_set.insert(node_mempool_kmalloc);
    // child_node_set.insert(node_mempool_alloc_pages);

    // for (PexCallGraph::CGNode * node_it : child_node_set) {
    //     node_it->callers.insert(std::pair<PexCallGraph::CGNode *, PexCallGraph::link_info *>(node_mempool_alloc, NULL));
    //     node_mempool_alloc->callees.insert(std::pair<PexCallGraph::CGNode *, PexCallGraph::link_info *>(node_it, NULL));
    // }
}

bool ___check_GFP_ACCOUNT_bit(llvm::Value *v) {
    if (llvm::isa<llvm::ConstantInt>(v))
    {
        llvm::ConstantInt* cd = llvm::dyn_cast<llvm::ConstantInt>(v);
        long long temp_flag = cd->getSExtValue();
        if (temp_flag < 0) {
            temp_flag = (temp_flag+1)*(-1);
        }
        if(temp_flag == __GFP_ACCOUNT) {
            return true;

        }
        // TODO: here I only check the __GFP_ACCOUNT bit, for `~__GFP_ACCOUNT` and other, not check
    }
    return false;
}

/*
 * this function checks whether the Value* v comes from Function* f_ptr's arguments
 * 
 * @v:          the temp Value to check if it contains the __GFP_ACCOUNT bit `0x400000u`
 * @isChecked:  used to aviod recursion
 * @bb_set_bit: if this Value is an intruction and it contains the value __GFP_ACCOUNT, we will
 *              add the basic block it belongs to the set @bb_set_bit
 * 
 * If this value or its users contains the __GFP_ACCOUNT, return true
 * If not, return false
 * 
 */
bool ___recursive_check_if_change_account_bit(llvm::Function* f_ptr, llvm::Value *v, std::unordered_set<llvm::Value *> isChecked, std::set<llvm::BasicBlock*> bb_set_bit) {
    if (v == NULL)
    {
        return false;
    }

    if (isChecked.find(v) != isChecked.end())
    {
        return false;
    }

    // initialze
    isChecked.insert(v);

    // @v is the arguments of @f_ptr
    if (___check_if_argument(f_ptr, v) >= 0)
    {
        // v is an argument
        return false;
    }

    /*
     * we have to solve many case here, for the Value* @v could be phi, and, or, ...
     * 
     * implemented: phi, or, and, select, load, call
     * 
     */

    if (llvm::isa<llvm::Constant>(v))
    {
        
        // TODO: need complete
#ifdef DEBUG_ACCOUNT_BIT
        llvm::errs() << "Constant:\n";
        llvm::errs() << *v << "\n";
#endif
        return false; 
    }
    else if (llvm::isa<llvm::Instruction>(v))
    {
        if (llvm::isa<llvm::CallBase>(v))
        {
            // like %5 = call i32 @mapping_gfp_mask.25625(%struct.address_space.117655* %0) #43
            // maybe this can be avoided by inline pass
            // corner case to be disscus
#ifdef DEBUG_ACCOUNT_BIT
            llvm::errs() << "CallBase:\n";
            llvm::errs() << *v << "\n";
            // ___get_dbg_loc(llvm::dyn_cast<llvm::Instruction>(v));
#endif
            return false;
        }
        else if (llvm::isa<llvm::BinaryOperator>(v))
        {
            // only or instruction is needed, for we want to know who change the GFP bit
            llvm::BinaryOperator *bo = llvm::dyn_cast<llvm::BinaryOperator>(v);

            for(unsigned i = 0; i<2; i++) {
                // check first operands
                if (llvm::isa<llvm::ConstantInt>(bo->getOperand(i))){
                    if (___check_GFP_ACCOUNT_bit(bo->getOperand(i)))
                    {
#ifdef DEBUG_ACCOUNT_BIT
                        llvm::errs() << "catch GFP_ACCOUNT:\n";
                        llvm::errs() << f_ptr->getName() << "\n";
                        llvm::errs() << *bo << "\n";
#endif
                        return true;
                    }
                }
                else
                {
                    if(___recursive_check_if_change_account_bit(f_ptr, bo->getOperand(i), isChecked, bb_set_bit)) {
                        return true;
                    }
                }
            }

            return false;
        }
        else if (llvm::isa<llvm::SelectInst>(v))
        {
            // for a select instruction like
            //     %.1 = select i1 %or.cond, i32 %40, i32 %.02
            // we should check true value %40 and false value %0.2
            llvm::SelectInst *si = llvm::dyn_cast<llvm::SelectInst>(v);
            // check true value
            if (___recursive_check_if_change_account_bit(f_ptr, si->getTrueValue(), isChecked, bb_set_bit))
            {
                return true;
            }

            // check false value
            return ___recursive_check_if_change_account_bit(f_ptr, si->getFalseValue(), isChecked, bb_set_bit);
        }
        else if (llvm::isa<llvm::PHINode>(v))
        {
            // for a phi node instruction like
            //     %.12 = phi i32 [ %22, %32 ], [ %58, %56 ], [ %52, %51 ]
            //     <result> = phi [fast-math-flags] <ty> [ <val0>, <label0>], ...
            //
            // we should check each possible value (%22, %58, %52)
            llvm::PHINode *phi_node = llvm::dyn_cast<llvm::PHINode>(v);
            for (llvm::Value *val_it : phi_node->incoming_values())
            {
                if (___recursive_check_if_change_account_bit(f_ptr, val_it, isChecked, bb_set_bit))
                {
                    return true;
                }
            }
            return false;
        }
        else if (llvm::isa<llvm::LoadInst>(v)) {
            // load instruction
            // solve those alloca %1, store %gfp to %1, %2 = load %1
            llvm::LoadInst *ld = llvm::dyn_cast<llvm::LoadInst>(v);
            for (auto it : ___get_all_store_from_load(ld)) {
                if (___recursive_check_if_change_account_bit(f_ptr, it, isChecked, bb_set_bit))
                {
                    return true;
                }
            }
            return false;
        }
        else if(llvm::isa<llvm::CastInst>(v)) {
            if (llvm::TruncInst* ti = llvm::dyn_cast<llvm::TruncInst>(v)) {
                return ___recursive_check_if_change_account_bit(f_ptr, ti->getOperand(0), isChecked, bb_set_bit);
            }
            else if (llvm::ZExtInst* zei = llvm::dyn_cast<llvm::ZExtInst>(v)) {
                return ___recursive_check_if_change_account_bit(f_ptr, zei->getOperand(0), isChecked, bb_set_bit);
            }
            else if (llvm::BitCastInst* bci = llvm::dyn_cast<llvm::BitCastInst>(v)) {
                return ___recursive_check_if_change_account_bit(f_ptr, bci->getOperand(0), isChecked, bb_set_bit);
            }
#ifdef DEBUG_ACCOUNT_BIT
            // TODO: need complete
            llvm::errs() << "CastInst:\n";
            llvm::errs() << *v << "\n";
            // ___get_dbg_loc(llvm::dyn_cast<llvm::Instruction>(v));
#endif
        }

#ifdef DEBUG_ACCOUNT_BIT
        // TODO: need complete
        llvm::errs() << "Instruction:\n";
        llvm::errs() << *v << "\n";
        // ___get_dbg_loc(llvm::dyn_cast<llvm::Instruction>(v));
#endif
        return false;
    }
    else if (llvm::isa<llvm::Operator>(v))
    {
#ifdef DEBUG_ACCOUNT_BIT
        // TODO: need complete
        llvm::errs() << "Operator:\n";
        llvm::errs() << *v << "\n";
#endif
        return false;
    }
    else
    {
#ifdef DEBUG_ACCOUNT_BIT
        // TODO: need complete
        llvm::errs() << "Unknow:\n";
        llvm::errs() << *v << "\n";
#endif
        return false;
    }
}

/*
 * this function checks whether the Value* v comes from Function* f_ptr's arguments
 * 
 * @f_ptr:      the function we want to check if it is an allocator
 * @v:          the temp Value to check if it is an argument of @f_ptr, or it comes from argument
 * @isChecked:  used to aviod recursion
 * 
 * If it is, we return the argument index
 * If not, we return -1
 * 
 * this function is recursively called in order to traverse LLVM use-def chain 
 * 
 */
int ___recursive_check_if_from_argument(llvm::Function *f_ptr, llvm::Value *v, std::unordered_set<llvm::Value *> isChecked)
{
    if (v == NULL || f_ptr == NULL)
    {
        return -1;
    }

    if (isChecked.find(v) != isChecked.end())
    {
        return -1;
    }

    // initialze
    isChecked.insert(v);
    int ret = -1;

    // @v is the arguments of @f_ptr
    ret = ___check_if_argument(f_ptr, v);
    if (ret >= 0)
    {
        // v is an argument, ret is its index
        return ret;
    }


    /*
     * we have to solve many case here, for the Value* @v could be phi, and, or, ...
     * 
     * here I just pick allocate_slab(struct kmem_cache *s, gfp_t flags, int node) as an example
     * 
     * phi: (we have to trace all possible value, such as %19 and %32)
     *     %.010 = phi i32 [ %32, %30 ], [ %19, %22 ], [ %19, %14 ]
     * 
     * or: (trace each operands, if const, just skip)
     *     %17 = or i32 %10, %16
     * 
     * and: (trace each operands, if const, just skip)
     *     %18 = and i32 %17, -106497
     * 
     * TODO: find more possible value type and give specific solution to each
     * 
     * phi, or, and, select, load, call
     * 
     */

    if (llvm::isa<llvm::Constant>(v))
    {
        if (llvm::isa<llvm::ConstantData>(v))
        {
            // like i32 77248
            return ret;
        }
        // TODO: need complete
#ifdef ARG_DEBUG
        llvm::errs() << "Constant:\n";
        llvm::errs() << *v << "\n";
#endif
        return ret;
    }
    else if (llvm::isa<llvm::Instruction>(v))
    {
        if (llvm::isa<llvm::CallBase>(v))
        {
            // like %5 = call i32 @mapping_gfp_mask.25625(%struct.address_space.117655* %0) #43
            // maybe this can be avoided by inline pass
            // corner case to be disscus
#ifdef ARG_DEBUG
            llvm::errs() << "CallBase:\n";
            llvm::errs() << *v << "\n";
            ___get_dbg_loc(llvm::dyn_cast<llvm::Instruction>(v));
#endif
            return ret;
        }
        else if (llvm::isa<llvm::BinaryOperator>(v))
        {
            // cover and, or, shl, ...
            // the BinaryOperator has 2 operands, we have to check both
            llvm::BinaryOperator *bo = llvm::dyn_cast<llvm::BinaryOperator>(v);
            // check first operands
            int op0_ret = ___recursive_check_if_from_argument(f_ptr, bo->getOperand(0), isChecked);
            if (op0_ret >= 0)
            {
                return op0_ret;
            }

            // check second operands
            int op1_ret = ___recursive_check_if_from_argument(f_ptr, bo->getOperand(1), isChecked);
            return op1_ret;
        }
        else if (llvm::isa<llvm::SelectInst>(v))
        {
            // for a select instruction like
            //     %.1 = select i1 %or.cond, i32 %40, i32 %.02
            // we should check true value %40 and false value %0.2
            llvm::SelectInst *si = llvm::dyn_cast<llvm::SelectInst>(v);
            // check true value
            int true_val_ret = ___recursive_check_if_from_argument(f_ptr, si->getTrueValue(), isChecked);
            if (true_val_ret >= 0)
            {
                return true_val_ret;
            }

            // check false value
            int false_val_ret = ___recursive_check_if_from_argument(f_ptr, si->getFalseValue(), isChecked);
            return false_val_ret;
        }
        else if (llvm::isa<llvm::PHINode>(v))
        {
            // for a phi node instruction like
            //     %.12 = phi i32 [ %22, %32 ], [ %58, %56 ], [ %52, %51 ]
            //     <result> = phi [fast-math-flags] <ty> [ <val0>, <label0>], ...
            //
            // we should check each possible value (%22, %58, %52)
            llvm::PHINode *phi_node = llvm::dyn_cast<llvm::PHINode>(v);
            for (llvm::Value *val_it : phi_node->incoming_values())
            {
                int temp_val_ret = ___recursive_check_if_from_argument(f_ptr, val_it, isChecked);
                if (temp_val_ret >= 0)
                {
                    return temp_val_ret;
                }
            }
            return ret;
        }
        else if (llvm::isa<llvm::LoadInst>(v)) {
            // load instruction
            // solve those alloca %1, store %gfp to %1, %2 = load %1
            llvm::LoadInst *ld = llvm::dyn_cast<llvm::LoadInst>(v);
            for (auto it : ___get_all_store_from_load(ld)) {
                int temp_val_ret = ___recursive_check_if_from_argument(f_ptr, it, isChecked);
                if (temp_val_ret >= 0)
                {
                    return temp_val_ret;
                }
            }
            return ret;
        }

#ifdef ARG_DEBUG
        // TODO: need complete
        llvm::errs() << "Instruction:\n";
        llvm::errs() << *v << "\n";
        ___get_dbg_loc(llvm::dyn_cast<llvm::Instruction>(v));
#endif
        return ret;
    }
    else if (llvm::isa<llvm::Operator>(v))
    {
#ifdef ARG_DEBUG
        // TODO: need complete
        llvm::errs() << "Operator:\n";
        llvm::errs() << *v << "\n";
#endif
        return ret;
    }
    else
    {
#ifdef ARG_DEBUG
        // TODO: need complete
        llvm::errs() << "Unknow:\n";
        llvm::errs() << *v << "\n";
#endif
        return ret;
    }

    // // although @v is not an argument, its parent user could be
    // // so we have to traverse the use-def chain to confirm its ancestors
    // for (llvm::Value* iter_user : v->users()) {
    //     ret = ___recursive_check_if_from_argument(f_ptr, iter_user, isChecked);
    //     if(ret >= 0) {
    //         return ret;
    //     }
    // }

    return ret;
}

/*
 * this function is the *heart function* of allocator collecting
 * 
 * An allocator needs to satisfy 2 rules:
 *   1. return i8* in LLVM IR
 *   2. have one `gfp_t` as its argument 
 * 
 * It is quite easy to get its return type, but we have to confirm this
 * function's argument, check if it is finally used in the call instruction
 * 
 * We can use MemAlloctor to get the `gfp_t` argument index
 * and then analyse its source
 * 
 * TODO: Add data flow analysis to confirm the return of the callInst will pass
 * to the return value
 * 
 */
bool AllocatorCollector::__recursive_checkAllocator(llvm::Function *f_ptr, llvm::Function *callee, llvm::CallBase *cb, std::unordered_set<llvm::Function *> isChecked)
{
    if (!f_ptr || !cb)
    {
        return false;
    }

    if (f_ptr == callee) {
        // avoid self calling
        // like `pskb_carve()`
        return false;
    }

    if (isChecked.find(f_ptr) != isChecked.end())
    {
        if(this->_function_set_.find(f_ptr) != this->_function_set_.end()) {
            return true;
        } else {
            return false;
        }
    }

    bool flag_isAllocator = false;
    // if this function has gfp_t flag, but ret value is not void* or page*
    // set this flag to check its ancestors
    bool flag_needDeepCheck = false;

    isChecked.insert(f_ptr);

#ifdef DEBUG_ALLOCATOR
    llvm::errs() << "cb:     " << *cb << "\n";
    llvm::errs() << "callee: " << callee->getName() << "\n";
    llvm::errs() << "caller: " << f_ptr->getName() << "\n";
#endif

    // first we need to analyse the dataflow to confirm the argument if it is `gfp_t`
    unsigned gfp_index = this->_allocator_map_[callee]->getFlagArgIndex();
    llvm::Value *gfp_passed = cb->getArgOperand(gfp_index);

    int arg_index = ___recursive_check_if_from_argument(f_ptr, gfp_passed, std::unordered_set<llvm::Value *>());
    if (arg_index >= 0)
    {    
        std::set<llvm::BasicBlock*> bb_contain_account_bit;
        bool isContain_GFP_ACCOUNT = ___recursive_check_if_change_account_bit(f_ptr, gfp_passed, std::unordered_set<llvm::Value *>(), bb_contain_account_bit);
        if(isContain_GFP_ACCOUNT) {
#ifdef DEBUG_ACCOUNT_BIT
            llvm::errs() << "catch function: " << f_ptr->getName() << "\n";
#endif
            // this function contains __GFP_ACCOUNT
            // we confirm it is not an allocator
            return false;
        }

        RET_TYPE retType = RET_TYPE::ELSE;

        // the gfp_passed is from the argument, so then we check the return value
        if (___check_ret_is_i8_ptr(f_ptr)) {
            // just add it to AllocatorCollector(this)
            //
            // TODO: we have not get the offset of the accounting bit yet, so just set it to 0
            flag_isAllocator = true;
            retType = RET_TYPE::VOID_PTR;
        } else if (___check_ret_is_page_ptr(f_ptr, this->_module_)) {
            flag_isAllocator = true;
            retType = RET_TYPE::PAGE_PTR;
        } else {
            // do have gfp_t flag, but ret value is not void* or page*
            // need further confirm
            // If its ancestor is Allocator, then this function is an allocator
            flag_needDeepCheck = true;
        }

        // here we just add new allocator(in oder to serve the further check), 
        // when the check result of ancestors received, we have to check:
        //     **is a needDeepCheck function's ancestor is allocator**
        // if not, we just remove it from set
        __addNewAllocator(f_ptr, arg_index, CHARGE_BIT, retType);

        bool flag_ancestorIsAllocator = false;

        // we have to check all callers of this function, in order to find all allocators
        PexCallGraph::CGNode *current_node = gCallGraph.getNode(f_ptr);
        for (auto it : current_node->callers)
        {
            if(it.first->f == callee) {
                // avoid circle
                // such as: skb_copy_ubufs and pskb_expand_head pair
                continue;
            }
            if(__recursive_checkAllocator(it.first->f, f_ptr, it.second->call, isChecked)) {
                flag_ancestorIsAllocator = true;
            }
        }

        if(flag_needDeepCheck) {
            if(flag_ancestorIsAllocator) {
                // and set the flag to true, and keep it in the set
                flag_isAllocator = true;
            } else {
                // now we check this function's ancestor and find no Allocator
                // so this function is not in an Allocator call chain
                // we can remove this function from the set confidently
                __removeAllocator(f_ptr);
            }
        }
    }
    return flag_isAllocator;
}

/*
 * Create a new MemAllocator instance and add it to AllocatorCollector(this)
 */
void AllocatorCollector::__addNewAllocator(llvm::Function *f_ptr, int flagIndex, int accountOffset, RET_TYPE retType)
{
    MemAllocator *new_allocator = new MemAllocator(f_ptr, flagIndex, accountOffset, CheckExported(f_ptr, _module_), retType);
    this->_alloctor_set_.insert(new_allocator);
    this->_function_set_.insert(f_ptr);
    this->_allocator_map_.insert(std::pair<llvm::Function *, MemAllocator *>(f_ptr, new_allocator));
}

// remove a funtion from Allocator set
void AllocatorCollector::__removeAllocator(llvm::Function* remove_fn) {
    MemAllocator* remove_mem = this->getMemAllocator(remove_fn);
    this->_function_set_.erase(remove_fn);
    this->_alloctor_set_.erase(remove_mem);
    this->_allocator_map_.erase(remove_fn);
}

AllocatorCollector::AllocatorCollector(llvm::Module &M)
{
    this->_module_ = &M;
    // get all possible allocators and store them into the _alloctor_set_
    __collectAllAllocators();
}

bool AllocatorCollector::isAllocator(llvm::Function *f_ptr)
{
    if (this->_allocator_map_.find(f_ptr) != this->_allocator_map_.end())
    {
        if (this->_alloctor_set_.find(this->_allocator_map_[f_ptr]) != this->_alloctor_set_.end())
        {
            return true;
        }
    }
    return false;
}

std::set<llvm::Function *> AllocatorCollector::getAllocateFunctions()
{
    return this->_function_set_;
}

MemAllocator *AllocatorCollector::getMemAllocator(llvm::Function *f_ptr)
{
    if (this->_allocator_map_.find(f_ptr) != this->_allocator_map_.end())
    {
        return this->_allocator_map_[f_ptr];
    }
    else
    {
        return NULL;
    }
}

MemAllocator* MemAllocator::newKMCreator(llvm::Function *function) {
    return new MemAllocator(function, 3, 26, true, RET_TYPE::ELSE);
}

llvm::Function *MemAllocator::getFunction()
{
    return this->_allocfunc_;
}

unsigned MemAllocator::getFlagArgIndex()
{
    return this->_flag_arg_index_;
}

int MemAllocator::getAccountOffset()
{
    return this->_account_offset_;
}

RET_TYPE MemAllocator::getRetType()
{
    return this->_ret_type_;
}

bool MemAllocator::isKMCAllocator() {
    auto funcname = _allocfunc_->getName().str();
    if (funcname.find("kmem_cache_alloc") != funcname.npos)
        return true;
    return false;
}