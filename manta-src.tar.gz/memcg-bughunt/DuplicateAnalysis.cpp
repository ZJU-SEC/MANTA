#include "DuplicateAnalysis.h"
#include "MemcgInterfaceCollector.h"
#include "AllocatorCollector.h"
#include "ReferencePaths.h"
#include "PexCallGraph.h"

extern PexCallGraph gCallGraph;

bool DuplicateAnalysis::getResult(int type) {
    if (type == CHARGE) {
        return dupChargeAnalysis();
    }
    return dupUnchargeAnalysis();
}

bool DuplicateAnalysis::dupChargeAnalysis() {
    MemcgInterfaceCollector mic(*_module_);
    auto sum_umem = mic.generateChargeSummary(MemcgInterfaceCollector::UMEM);
    auto sum_sk = mic.generateChargeSummary(MemcgInterfaceCollector::SOCKET);
    std::map<llvm::Function*, std::vector<std::pair<llvm::CallInst*, int>>> caller_records;
    // auto alloc_funcs = ac.getAllocateFunctions();
    // for (auto alloc_func : alloc_funcs) {
    //     auto ele_ty = alloc_func->getReturnType();
    //     if (ele_ty->isPointerTy())
    //         ele_ty = ele_ty->getPointerElementType();
    //     if (auto *stty = llvm::dyn_cast<llvm::StructType>(ele_ty)) {
    //         if (stty->hasName() && (
    //           to_struct_name(stty->getName().str()) == "struct.page")) {
    //             sum_umem.insert(std::make_pair(alloc_func, -1));
    //         }
    //     }
    // }
    for (auto item : sum_umem) {
        auto *charge_func = item.first;
        int idx = item.second;
        auto callsites = gCallGraph.findCallSites(charge_func);
        for (auto callsite : callsites) {
            auto *caller = callsite->getFunction();
            auto iter = caller_records.find(caller);
            if (iter == caller_records.end()) {
                caller_records[caller].push_back(std::make_pair(callsite, idx));
            }
            else {
                iter->second.push_back(std::make_pair(callsite, idx));
            }
        }
    }
    for (auto item : sum_sk) {
        auto *charge_func = item.first;
        int idx = item.second;
        auto callsites = gCallGraph.findCallSites(charge_func);
        for (auto callsite : callsites) {
            auto *caller = callsite->getFunction();
            auto iter = caller_records.find(caller);
            if (iter == caller_records.end()) {
                caller_records[caller].push_back(std::make_pair(callsite, idx));
            }
            else {
                iter->second.push_back(std::make_pair(callsite, idx));
            }
        }
    }
    for (auto item : caller_records) {
        handleRecord(item.second);
    }
    return true;
}

bool DuplicateAnalysis::dupUnchargeAnalysis() {
    return true;
}

bool DuplicateAnalysis::handleRecord(std::vector<std::pair<llvm::CallInst*, int>> cs_info) {
    // if (cs_info.size() <= 1)
    //     return true;
    std::vector<llvm::CallInst*> allocCalls;
    for (auto &BB : *cs_info[0].first->getFunction()) {
        for (auto &I : BB) {
            if (auto *callinst = llvm::dyn_cast<llvm::CallInst>(&I)) {
                auto *cf = callinst->getCalledFunction();
                if (cf && _allocator_collector_->isAllocator(cf))
                    allocCalls.push_back(callinst);
            }
        }
    }
    for (int i = 0; i < cs_info.size(); ++i) {
        for (int j = i + 1; j < cs_info.size(); ++j) {
            if(isDupCall(cs_info[i].first, cs_info[j].first, cs_info[i].second, cs_info[j].second)) {
                llvm::errs() << "Potential duplicate charge found at " << cs_info[0].first->getFunction() << "\n";
                print_debugloc(cs_info[i].first, llvm::errs());
                print_debugloc(cs_info[j].first, llvm::errs());
                llvm::errs() << "\n";
            }
        }
        // verify if come from allocator
        ReferencePaths rps(cs_info[i].first->getFunction());
        rps.addPath(cs_info[i].first->getArgOperand(cs_info[i].second), {0});
        for (auto *callinst : allocCalls) {
            if (rps.getPath(callinst).size() > 0) {
                llvm::errs() << "Potential duplicate charge found at " << cs_info[0].first->getFunction()->getName() << "\n";
                print_debugloc(cs_info[i].first, llvm::errs());
                print_debugloc(callinst, llvm::errs());
                llvm::errs() << "\n";
            }
        }
    }
    return true;
}

bool DuplicateAnalysis::isDupCall(llvm::CallInst *first, llvm::CallInst *second, int idx1, int idx2) {
    ReferencePaths rps(first->getFunction());
    rps.addPath(first->getArgOperand(idx1), {0});
    auto rp = rps.getPath(second->getArgOperand(idx2));
    if (rp.size() == 0)
        return false;
    if (!llvm::isPotentiallyReachable(first->getParent(), second->getParent()) && !llvm::isPotentiallyReachable(second->getParent(), first->getParent()))
        return false;
    return true;
}