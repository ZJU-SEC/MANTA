#include "Project.h"

static inline void blistToIlist(blist &bl, Instruction *stop, iseq &il) {
  for(LLVMSliceBlock *bb : bl){
    LLVMSliceBlock::inst_iterator i = bb->inst_begin(), ie = bb->inst_end();
    for(; i != ie; ++i){
      il.push_back(*i);
    }
  }

  // trim off from stop inst
  while(il.back() != stop){
    il.pop_back();
  }
}

static inline void dumpValueSymbol(Value *val, SEGraph &seg, SymExec &sym) {
  SENode *node = seg.getNodeProbe(val);
//  assert(node != nullptr);
  if (node== nullptr){
    return;
  }


  SymVar *svar = sym.getVar(node);
  if(svar == nullptr){
    errs() << "<unknown>\n";
  } else {
    svar->dump(sym.getContext());
  }
}

class Traces{
public:
    Traces(Function *f,CallInst *inst,CallInst* root,ModuleOracle& mo):func(f),targetInst(inst),root(root),mo(mo),
                                                                     fo(*func, mo.getDataLayout()){
    lowerSwitch(*f);

//    f->viewCFG();

    fo.getReachBlocks(targetInst->getParent(), reach);
    Slice slice=Slice(reach, targetInst);
    if (slice.ifAborted()){
      outs()<<"slice aborted\n";
      exit(-1);
    }
    LLVMSlice wrap(&slice);

    SliceOracle oracle(wrap);

    // unroll
    UnrollPath *unrolled = oracle.getUnrolled(&wrap.getBasisBlock());
    iseq trace;
    for (auto it=unrolled->begin();it!=unrolled->end();++it){
      blistToIlist(**it, targetInst, trace);
      segs.push_back(new SEGraph(&oracle, trace,*func));
      trace.clear();
    }

  }

  ~Traces(){
    //outs()<<"delete traces\n";
    for (auto seg:segs){
      //outs()<<seg<<"\n";
      delete seg;
    }
  }

public:
  Function *func;
  CallInst *root;
  CallInst *targetInst;

  ModuleOracle &mo;
  FuncOracle fo;
  vector<SEGraph*> segs;
  set<BasicBlock *> reach;
};

class TestPass: public ModulePass {
  public:
    static char ID;

    TestPass(): ModulePass(ID){}
    ~TestPass(){}

    void getAnalysisUsage(AnalysisUsage &au) const {
        ModulePass::getAnalysisUsage(au);
        au.addRequired<TargetLibraryInfoWrapperPass>();
        au.setPreservesAll();
    }
    bool runOnModule(Module &m) override;

    void merge(SEGraph* seg,vector<Traces> &traces,int pos,ModuleOracle& mo);
    void inputCallChain(std::vector<pair<Function*,CallInst*>> &targets);
  private:
    std::vector<pair<Function*,CallInst*>> targets;
};

