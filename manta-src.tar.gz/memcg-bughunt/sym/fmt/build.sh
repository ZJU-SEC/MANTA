#!/bin/bash
mkdir build && cd "$_"
cmake .. -DBUILD_SHARED_LIBS=true && make
