#ifndef INTRINSIC_CLEANER_H
#define INTRINSIC_CLEANER_H

void cleanIntrinsics(Module &m, const DataLayout& dl);
#endif /* INTRINSIC_CLEANER_H */
