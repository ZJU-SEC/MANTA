#ifndef LOWER_H_
#define LOWER_H_

void lowerSwitch(Function &f);
void breakConstantExpr(Module &m); 

#endif /* LOWER_H_ */
