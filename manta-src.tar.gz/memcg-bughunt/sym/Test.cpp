#include "Test.h"
Dumper DUMP;

char TestPass::ID = 0;

bool TestPass::runOnModule(Module &m) {
    ModuleOracle mo(m);

    // run module pass
    breakConstantExpr(m);

    // transform intrinsic functions
    // cleanIntrinsics(m, m.getDataLayout());


    //  Function *targetFunc= nullptr;
    //  vector<pair<Function*,CallInst*>> targets;

    //__se_compat_sys_waitid -> kernel_waitid -> do_wait
    //__se_compat_sys_waitid -> kernel_waitid -> find_get_pid
    //kernel_waitid -> find_get_pid

    // for (auto &func:m){
    //   if (func.getName()=="__x64_sys_exit_group"){
    //     targetFunc=&func;
    //     break;
    //   }
    // }
    // assert(targetFunc!= nullptr);
    // vector<string> funcNames{"__se_sys_exit_group","do_group_exit","zap_other_threads"};


    // int i=0;
    // Function* func=targetFunc;
    // bool changed;
    // do{
    //   changed=false;
    //   for (auto it=inst_begin(func);it!=inst_end(func);++it){
    //     if (auto *ci=dyn_cast<CallInst>(&*it)){
    //       if (ci->getCalledFunction()!= nullptr && ci->getCalledFunction()->getName()==funcNames[i]){
    //         //outs()<<*ci<<"\n";
    //         targets.emplace_back(func,ci);
    //         func=ci->getCalledFunction();
    //         changed=true;
    //         i++;
    //         break;
    //       }
    //     }
    //   }
    // } while (changed && i<funcNames.size());

    for (auto &item:targets){
      outs()<<item.first->getName()<<" "<<*(item.second)<<"\n";
    }
    outs()<<"\n";

    Traces traces(targets[0].first, targets[0].second,nullptr,mo);
    vector<Traces> v;
    v.reserve(targets.size()-1);
    for (int j = 1; j < targets.size(); ++j) {
      v.emplace_back(targets[j].first,targets[j].second,targets[j -1].second,mo);
    }

    for (auto seg:traces.segs){
      merge(seg,v,0,mo);
    }
}


void TestPass::merge(SEGraph *seg, vector<Traces> &traces, int pos,ModuleOracle &mo) {
    if (pos==traces.size()){

      SymExec sym(mo);
      seg->symbolize(sym);
      CheckResult res=sym.checkPathValid();
      outs()<<res<<"\n";
      if (res==CK_SAT){
        Z3_model model = sym.getModel();
        outs()<<Z3_model_to_string(sym.getContext(),model)<<"\n";
      }else{
        //seg->displayConds();
      }
      return;
    }
    for(auto calledSeg:traces[pos].segs){
      SEGraph newSeg=SEGraph(*seg);
      set<int> st;
      newSeg.mergeSEG(calledSeg,traces[pos].root,st);
      merge(&newSeg,traces,pos+1,mo);
    }
}

void TestPass::inputCallChain(std::vector<pair<Function*,CallInst*>> &targets) {
  this->targets = targets;
}




static RegisterPass<TestPass> TestPass("Test", "TestPass", false, true);