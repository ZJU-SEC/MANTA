#pragma once
#include "Utils.h"

class FreeInterfaceCollector {
public:
    enum FunctionKind {INNER = 1U, INTERFACE = 2U, OUTER = 4U, KMEM_UNC = 8U, UMEM_UNC = 16U, NONE_UNC = 32U};
    FreeInterfaceCollector(llvm::Module &);
    std::set<llvm::Function*> getFreeInterfaces();
    bool printGraph(llvm::raw_ostream &);
    static llvm::Value* getFreedObject(llvm::CallInst *);
private:
    
    llvm::Module* _module_;
    std::set<std::pair<llvm::Function*, int> > _free_seeds_;
    std::set<llvm::Function*> _free_ifs_;
    std::map<llvm::Function*, unsigned> _func_attrs_;
    std::set<llvm::Function*> _visited_funcs_;
    std::set<std::string> _edge_set_;
    std::set<std::pair<llvm::Function*, int> > _umem_uncifs_;
    std::set<std::pair<llvm::Function*, int> > _kmem_uncifs_;
    bool collect();
    bool collectSeed();
    // dot graph emitter
    int dfsWalk(llvm::Function *, llvm::Value*, int);
    int unchargeWalk(llvm::Function *, llvm::Value *, unsigned, int);
    int getSrcParamIndex(llvm::Function*, llvm::Value*);
    bool emitEdge(llvm::Function *caller, llvm::Function *callee);
    // deprecated
    static std::set<std::string> _freefunc_names_;
};
    