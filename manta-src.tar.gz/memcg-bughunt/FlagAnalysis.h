#pragma once
#include "Utils.h"

class MemAllocator;

class FlagAnalysis {
public:
    enum AccountType {NONE, KMEM_CACHE_CREATE, NORMAL, UNK};
    enum EvaluationResult {PROCESSING, TRUE, FALSE, UNKNOWN};
    // add kmem_cache judge in AllocatorCollector
    FlagAnalysis(MemAllocator *allocator, llvm::CallInst *callsite);
    AccountType getAccountType();
    std::set<llvm::Function*> getSpannedFunctions();
    int getLongestCallChain();
private:
    MemAllocator *_allocator_;
    llvm::CallInst *_callsite_;
    llvm::Module *_module_;
    int _bit_offset_;
    int _longest_cc_;
    int _cur_cc_;
    std::set<llvm::Function*> _gfp_spanned_;
    std::map<llvm::Value*, EvaluationResult> _evalres_;
    std::vector<std::vector<llvm::Value*>> _callcontext_;
    EvaluationResult isBitSet(llvm::Value *);
    EvaluationResult evalBinaryOperator(llvm::BinaryOperator *);
    EvaluationResult evalLoadInst(llvm::LoadInst *);
    EvaluationResult evalCallInst(llvm::CallInst *);
    EvaluationResult evalArgument(llvm::Argument *);
    bool trueOrProcessing(EvaluationResult &);
};