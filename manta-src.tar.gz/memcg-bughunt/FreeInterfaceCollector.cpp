#include "FreeInterfaceCollector.h"
#include "PexCallGraph.h"

extern PexCallGraph gCallGraph;

std::set<std::string> FreeInterfaceCollector::_freefunc_names_ = {"kfree", "vfree", "kvfree", "kmem_cache_free", "free_pages", "__free_pages"};

FreeInterfaceCollector::FreeInterfaceCollector(llvm::Module &module) {
    _module_ = &module;
    // instrumented according to result of MIC
    _umem_uncifs_.insert(std::make_pair(module.getFunction("mem_cgroup_uncharge"), 0));
    _umem_uncifs_.insert(std::make_pair(module.getFunction("mem_cgroup_uncharge_list"), 0));
    _kmem_uncifs_.insert(std::make_pair(module.getFunction("__memcg_kmem_uncharge_page"), 0));
    collectSeed();
}

std::set<llvm::Function*> FreeInterfaceCollector::getFreeInterfaces() {
    for (auto pair : _free_seeds_) {
        dfsWalk(pair.first, pair.first->getArg(pair.second), 0);
    }
    _visited_funcs_.clear();
    for (auto pair : _kmem_uncifs_) {
        unchargeWalk(pair.first, pair.first->getArg(pair.second), KMEM_UNC, 0);
    }
    _visited_funcs_.clear();
    for (auto pair : _umem_uncifs_) {
        unchargeWalk(pair.first, pair.first->getArg(pair.second), UMEM_UNC | KMEM_UNC, 0);
    }
    _visited_funcs_.clear();
    return _free_ifs_;
}

/* return 1 for non-free function
** return 0 for free function*/
int FreeInterfaceCollector::dfsWalk(llvm::Function *function, llvm::Value *target_val, int cur_hop) {
    auto callsites = gCallGraph.findCallSites(function);
    int pidx = getSrcParamIndex(function, target_val);
    int res = 0;
    if (cur_hop > 5)
        return 1;
    if (_visited_funcs_.count(function)) 
        return pidx == -1;
    if (pidx == -1) {
        _func_attrs_[function] = OUTER;
        return 1;
    }
    _visited_funcs_.insert(function);
    for (auto callsite : callsites) {
        auto caller_func = callsite->getFunction();
        emitEdge(caller_func, function);
        res = res + dfsWalk(caller_func, callsite->getArgOperand(pidx), cur_hop + 1);
    }
    if (res != 0) {
        _func_attrs_[function] = INTERFACE;
        _free_ifs_.insert(function);
    }
    else {
        _func_attrs_[function] = INNER;
    }
    return 0;
}

int FreeInterfaceCollector::unchargeWalk(llvm::Function *function, llvm::Value *target_val, unsigned unc_type, int cur_hop) {
    auto callsites = gCallGraph.findCallSites(function);
    int pidx = getSrcParamIndex(function, target_val);
    if (cur_hop > 9)
        return 0;
    if (_visited_funcs_.count(function) || pidx == -1)
        return 0;
    _visited_funcs_.insert(function);
    auto iter = _func_attrs_.find(function);
    if (iter != _func_attrs_.end()) {
        iter->second |= unc_type;
    }
    
    for (auto callsite : callsites) {
        auto caller_func = callsite->getFunction();
        emitEdge(caller_func, function);
        unchargeWalk(caller_func, callsite->getArgOperand(pidx), unc_type, cur_hop + 1);
    }
    return 1;
}

int FreeInterfaceCollector::getSrcParamIndex(llvm::Function *function, llvm::Value *target_val) {
    std::deque<llvm::Value*> pqueue;
    std::unordered_set<llvm::Value *> checked;
    pqueue.push_back(target_val);
    if (target_val == nullptr)
        return -1;
    while (!pqueue.empty()) {
        llvm::Value *curval = pqueue.front();
        checked.insert(curval);
        pqueue.pop_front();
        if (auto *arg = llvm::dyn_cast<llvm::Argument>(curval)) {
            // todo: add i8*
            auto ele_ty = arg->getType();
            if (ele_ty->isPointerTy())
                ele_ty = ele_ty->getPointerElementType();
            if (auto *stty = llvm::dyn_cast<llvm::StructType>(ele_ty)) {
                if (stty->hasName() && (
                  to_struct_name(stty->getName().str()) == "struct.page"
                  || to_struct_name(stty->getName().str()) == "struct.list_head"
                  || to_struct_name(stty->getName().str()) == "struct.per_cpu_pages")) {
                    return arg->getArgNo();
                }
            }
        }
        else if (auto *inst = llvm::dyn_cast<llvm::Instruction>(curval)){
            //if (!llvm::isa<llvm::CallInst>(inst)) {
                for (auto *opr : inst->operand_values()) {
                    if (checked.find(opr) == checked.end()) {
                        pqueue.push_back(opr);
                    }
                }
            //}
            auto stores = find_phi_select_user<llvm::StoreInst>(curval);
            for (auto sti : stores) {
            if (checked.find(sti->getOperand(0)) == checked.end()) {
                    pqueue.push_back(sti->getOperand(0));
                }
            }
        }
    }
    return -1;
}



bool FreeInterfaceCollector::collectSeed() {
    _free_seeds_.insert(std::make_pair(_module_->getFunction("__free_one_page"), 0));
    _free_seeds_.insert(std::make_pair(_module_->getFunction("free_pcppages_bulk"), 2));
    return true;
}

/*
** For indirect calls, we simply return nullptr
*/
llvm::Value* FreeInterfaceCollector::getFreedObject(llvm::CallInst *callinst) {
    llvm::Function *ct = getCallTarget(callinst);
    if (ct == nullptr)
        return nullptr;
    if (_freefunc_names_.find(to_function_name(ct->getName().str())) == _freefunc_names_.end())
        return nullptr;
    if (ct->getName().str().compare("kmem_cache_free") == 0)
        return callinst->getArgOperand(1);
    return callinst->getArgOperand(0);
}

bool FreeInterfaceCollector::emitEdge(llvm::Function *caller, llvm::Function *callee) {
    _edge_set_.insert(
                "  " 
                + to_function_name(caller->getName().str())
                + " -> "
                + to_function_name(callee->getName().str())
                + "\n"
            );
    return true;
}

bool FreeInterfaceCollector::printGraph(llvm::raw_ostream &os) {
    os << "digraph{\n";
    // todo: print node
    for (auto it : _func_attrs_) {
        auto *func = it.first;
        unsigned attr = it.second;
        std::string node = "  " + to_function_name(func->getName().str()) 
                + " [label=\"" 
                + to_function_name(func->getName().str()) 
                + "\" style=filled";
        if (attr & INNER) {
            node += " shape=circle";
        }
        else if (attr & INTERFACE) {
            node += " shape=doublecircle";
        }
        else if (attr & OUTER) {
            node += " shape=rectangle";
        }
        if ((attr & KMEM_UNC) && (attr & UMEM_UNC)) {
            node += " fillcolor=purple";
        }
        else if (attr & KMEM_UNC) {
            node += " fillcolor=red";
        }
        else if (attr & UMEM_UNC) {
            node += " fillcolor=blue";
        }
        node += "]\n";
        os << node;
    }
    for(auto it : _edge_set_) {
        os << it;
    }
    os << "}\n";
    return true;
} 
