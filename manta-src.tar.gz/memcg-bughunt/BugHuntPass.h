#pragma once
#include "Utils.h"


#define MAX_NUM_THREADS 40

class AllocatorCollector;

class BugHuntPass : public llvm::ModulePass
{
public:
    static char ID;
    BugHuntPass() : ModulePass(ID), _num_threads_(0) {};
    virtual bool runOnModule(llvm::Module &) override;
private:
    using FreeSites = std::map<llvm::Function *, llvm::CallInst *>;
    using WorkerFuture = std::future<std::result_of_t<std::decay_t<int (BugHuntPass::*)(llvm::CallInst*)>(std::decay_t<BugHuntPass*>, std::decay_t<llvm::CallInst*>)>>;
    llvm::Module *_module_;
    std::map<llvm::CallInst*, FreeSites> _allocs_free_sites_;
    std::unordered_set<llvm::CallInst*> _uncharged_allocs_;
    std::unordered_set<llvm::CallInst*> _unknown_allocs_;
    std::unordered_set<llvm::CallInst*> _charged_allocs_normal_;
    std::unordered_set<llvm::CallInst*> _charged_allocs_kmem_;
    static std::unordered_set<std::string> _excluded_allocator_;
    static std::unordered_set<std::string> _excluded_caller_;
    std::mutex _mu_afs_;
    std::atomic<int> _num_threads_; 
    AllocatorCollector *_allocfuncs_;
    void traceTaskEntry(std::vector<llvm::CallInst*> &, std::set<std::vector<llvm::CallInst*> > &, const std::map<llvm::Function*, llvm::CallInst *> &);
    void analyze();
    void generateResult(llvm::raw_ostream &);
    void analyzeFreeSites(llvm::Module *);
    int workerThread(llvm::CallInst *);
    std::vector<WorkerFuture>::iterator getFirstIdle(std::vector<WorkerFuture> &tasks);
    


};