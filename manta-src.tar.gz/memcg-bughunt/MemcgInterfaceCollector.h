#pragma once
#include "Utils.h"

// class FunctionSummary {
// public:
//     // -1 indicates that charged page is return value
//     llvm::Value *charged_page;
//     bool is_ret_page_charged;
//     llvm::Value *payer;
//     llvm::CallInst *charge_site;
    
// }

class MemcgInterfaceCollector {
public:
    
    enum FunctionKind {INNER, INTERFACE, OUTER};
    enum SummaryKind {KMEM, UMEM, SWAP, SOCKET};
    MemcgInterfaceCollector(llvm::Module &m):_module_(&m){ collectSeed(); }
    std::set<llvm::Function*> collectCharge();
    std::set<llvm::Function*> collectUncharge();
    std::map<llvm::Function*, int> generateChargeSummary(int);
    std::map<llvm::Function*, int> generateUnchargeSummary(int);
    bool printGraph(llvm::raw_ostream &os);

private:
    llvm::Module *_module_;
    std::vector<llvm::Function*> _charge_seed_;
    std::vector<llvm::Function*> _uncharge_seed_;
    std::set<std::string> _node_set_;
    std::set<std::string> _edge_set_;
    std::set<llvm::Function*> _charge_interfaces_;
    std::set<llvm::Function*> _uncharge_interfaces_;
    std::set<llvm::Function*> _visited_funcs_;
    // collect seed functions that modify struct page_counter.usage
    bool collectSeed();
    // dot graph emitter
    bool emitNode(llvm::Function *, FunctionKind);
    bool emitEdge(llvm::Function *caller, llvm::Function *callee);
    FunctionKind getKind(llvm::Function *function);
    bool dfsWalk(llvm::Function *, int, std::set<llvm::Function*> &);
    bool genSummary(llvm::Function *, llvm::Value *, int, std::map<llvm::Function*, int> &);
    int getSrcParamIndex(llvm::Function*, llvm::Value*, int);

};