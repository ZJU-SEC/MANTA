#pragma once
#include "Utils.h"
#include "ReferencePaths.h"

/* 
** Find functions where the allocated memory **must** be freed
*/
class AllocatorCollector;

class FreeSiteAnalysis {
public:
    struct SearchTask {
        ReferencePaths reference_paths;
        llvm::CallInst *callinst;
        unsigned cur_hop;
        SearchTask(llvm::Function *function): reference_paths(function), callinst(nullptr), cur_hop(0) {}
    };
    FreeSiteAnalysis(llvm::CallInst *allocsite, AllocatorCollector *allocfuncs);
    ~FreeSiteAnalysis();
    const std::map<llvm::Function *, llvm::CallInst *> &getFreeSites();
    bool mustFree(llvm::Function *);
private:
    bool findFreeSites();
    llvm::CallInst *findFreeSite(ReferencePaths &, llvm::CallInst *);
    bool evalCallInst(llvm::CallInst *);
    bool isIntegerCheckICmp(llvm::ICmpInst *, long, llvm::CmpInst::Predicate);
    bool isNullCheckICmp(llvm::ICmpInst *);
    bool isVisited(llvm::Function *);
    bool allowNext(SearchTask &);
    llvm::BasicBlock* findTargetBasicBlock(llvm::ICmpInst *);
    llvm::PostDominatorTree *createReachablePDT(llvm::Function *);
    unsigned _hoplimit_;
    std::deque<SearchTask> _pqueue_;
    std::map<llvm::Function *, llvm::CallInst *> _freesites_;
    std::unordered_set<llvm::Function *> _visitedfunc_;
    std::vector<ReferencePaths*> _callcontext_;
    llvm::CallInst *_allocsite_;
    llvm::Module *_module_;
    AllocatorCollector *_allocfuncs_;
    static std::mutex _mutex_;
    static std::map<llvm::Function*, llvm::PostDominatorTree*> _functopdt_;
    static const long min_err_no;
};