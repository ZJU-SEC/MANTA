#include "FlagAnalysis.h"
#include "PexCallGraph.h"
#include "AllocatorCollector.h"

extern PexCallGraph gCallGraph;

FlagAnalysis::FlagAnalysis(MemAllocator *allocator, llvm::CallInst *callsite) {
    assert(allocator); assert(callsite);
    _allocator_ = allocator;
    _callsite_ = callsite;
    _bit_offset_ = allocator->getAccountOffset();
    _module_ = callsite->getModule();
    _longest_cc_ = _cur_cc_ = 0;
    _gfp_spanned_.clear();
    _callcontext_.clear();
}

std::set<llvm::Function*> FlagAnalysis::getSpannedFunctions() {
    return _gfp_spanned_;
}

int FlagAnalysis::getLongestCallChain() {
    return _longest_cc_;
}

FlagAnalysis::AccountType FlagAnalysis::getAccountType() {
    auto *alloc_func = _allocator_->getFunction();
    auto flag_index = _allocator_->getFlagArgIndex();
    auto *flag_val = _callsite_->getArgOperand(flag_index);
    _gfp_spanned_.insert(_callsite_->getFunction());
    if (isBitSet(flag_val) == EvaluationResult::UNKNOWN)
        return AccountType::UNK;
    if (isBitSet(flag_val) == EvaluationResult::TRUE)
        return AccountType::NORMAL;
    if(_allocator_->isKMCAllocator()) {
        auto *cachep = _callsite_->getArgOperand(0);
        auto *ldi = llvm::dyn_cast<llvm::LoadInst>(cachep);
        if (ldi == nullptr) {
            llvm::errs() << "cachep LoadInst not found for callsite: ";
            print_debugloc(_callsite_, llvm::errs());
            llvm::errs() << "\n";
            return AccountType::NONE;
        }
        // just take the first loadinst
        auto *global_cachepp = llvm::dyn_cast<llvm::GlobalVariable>(stripConstCastExpr(ldi->getOperand(0)));
        if (global_cachepp == nullptr) {
            llvm::errs() << "global cachep not found for callsite: ";
            print_debugloc(_callsite_, llvm::errs());
            llvm::errs() << "\n";
            return AccountType::NONE;
        }
        // we do not consider constantexpr here
        auto cachep_stris = find_user<llvm::StoreInst>(global_cachepp);
        if (cachep_stris.empty()) {
            llvm::errs() << "cachep StoreInst not found for callsite: ";
            print_debugloc(_callsite_, llvm::errs());
            llvm::errs() << "\n";
            return AccountType::NONE;
        }
        auto &stri = cachep_stris.front();
        auto *cachep_created = stri->getOperand(0);
        auto *cachep_create_call = llvm::dyn_cast<llvm::CallInst>(stri->getOperand(0));
        if (cachep_create_call == nullptr) {
            llvm::errs() << "cachep creating CallInst not found for callsite: ";
            print_debugloc(_callsite_, llvm::errs());
            llvm::errs() << "\n";
            return AccountType::NONE;
        }
        auto *create_func = cachep_create_call->getCalledFunction();
        if (create_func == nullptr) {
            llvm::errs() << "Indirect call to kmem_cache creator function found for callsite: ";
            print_debugloc(_callsite_, llvm::errs());
            llvm::errs() << "\n";
            return AccountType::NONE;
        }
        if (create_func->getName().str() != "kmem_cache_create" && create_func->getName().str() != "kmem_cache_create_usercopy") {
            llvm::errs() << "New kmem_cache creating function found: " << create_func->getName().str() << "\n";
            return AccountType::NONE;
        }
        MemAllocator *kmc_creator = MemAllocator::newKMCreator(create_func);
        auto temp_bit_offset = _bit_offset_;
        auto temp_evalres = _evalres_;
        _bit_offset_ = kmc_creator->getAccountOffset();
        _evalres_.clear();
        auto res = isBitSet(cachep_create_call->getArgOperand(kmc_creator->getFlagArgIndex()));
        _evalres_ = temp_evalres;
        _bit_offset_ = temp_bit_offset;
        delete kmc_creator;
        if (res == EvaluationResult::TRUE)
            return AccountType::KMEM_CACHE_CREATE;
        // how about EvaluationResult::UNKNOWN?
    }
    return AccountType::NONE;
}

FlagAnalysis::EvaluationResult FlagAnalysis::isBitSet(llvm::Value *value) {
    assert(value);
    _cur_cc_ = 0;
    if (auto *c = llvm::dyn_cast<llvm::Constant>(value)) {
        auto *cstripped = stripConstCastExpr(c);
        auto *cint = llvm::dyn_cast<llvm::ConstantInt>(cstripped);
        assert(cint);
        uint64_t mask = 1ULL << _bit_offset_;
        if (cint->getZExtValue() & mask)
            return EvaluationResult::TRUE;
        return EvaluationResult::FALSE;
    }
    auto curiter = _evalres_.insert(std::make_pair(value, EvaluationResult::PROCESSING)).first;
    if (auto *inst = llvm::dyn_cast<llvm::Instruction>(value)) {
        _gfp_spanned_.insert(inst->getFunction());
    }
    else if (auto *arg = llvm::dyn_cast<llvm::Argument>(value)) {
        _gfp_spanned_.insert(arg->getParent());
    }
    if (auto *ci = llvm::dyn_cast<llvm::CastInst>(value)) {
        auto it = _evalres_.find(ci->getOperand(0));
        EvaluationResult er = (it != _evalres_.end() ? it->second : isBitSet(ci->getOperand(0)));
        if (er == EvaluationResult::PROCESSING) {
            llvm::errs() << *ci << "\nOperand in processing.\n";
            goto label_false;
        }
        if (er == EvaluationResult::TRUE)
            goto label_true;
        if (er == EvaluationResult::FALSE)
            goto label_false;
        if (er == EvaluationResult::UNKNOWN)
            goto label_unknown;
    }
    else if (auto *si = llvm::dyn_cast<llvm::SelectInst>(value)) {
        auto it_true = _evalres_.find(si->getTrueValue());
        auto it_false = _evalres_.find(si->getFalseValue());
        EvaluationResult er_true = (it_true != _evalres_.end() ? it_true->second : isBitSet(si->getTrueValue()));
        EvaluationResult er_false = (it_false != _evalres_.end() ? it_false->second : isBitSet(si->getFalseValue()));
        assert(er_true != EvaluationResult::PROCESSING || er_false != EvaluationResult::PROCESSING);
        if (er_true == EvaluationResult::UNKNOWN || er_false == EvaluationResult::UNKNOWN)
            goto label_unknown;
        if (er_true == EvaluationResult::FALSE || er_false == EvaluationResult::FALSE) {
            goto label_false;
        }
        goto label_true;
    }
    else if (auto *phi = llvm::dyn_cast<llvm::PHINode>(value)) {
        bool unknown_flag = 0;
        for (unsigned i = 0; i < phi->getNumIncomingValues(); ++i) {
            auto it = _evalres_.find(phi->getIncomingValue(i));
            EvaluationResult er = (it != _evalres_.end() ? it->second : isBitSet(phi->getIncomingValue(i)));
            if (er == EvaluationResult::FALSE)
                goto label_false;
            if (er == EvaluationResult::UNKNOWN)
                unknown_flag = 1;
        }
        if (unknown_flag)
            goto label_unknown;
        goto label_true;
    }
    else if (auto *bo = llvm::dyn_cast<llvm::BinaryOperator>(value)) {
        auto er = evalBinaryOperator(bo);
        if (er == EvaluationResult::TRUE)
            goto label_true;
        if (er == EvaluationResult::FALSE)
            goto label_false;
        if (er == EvaluationResult::UNKNOWN)
            goto label_unknown;
    }
    else if (auto *ldi = llvm::dyn_cast<llvm::LoadInst>(value)) {
        auto er = evalLoadInst(ldi);
        if (er == EvaluationResult::TRUE)
            goto label_true;
        if (er == EvaluationResult::FALSE)
            goto label_false;
        if (er == EvaluationResult::UNKNOWN)
            goto label_unknown;
    }
    else if (auto *ci = llvm::dyn_cast<llvm::CallInst>(value)) {
        auto er = evalCallInst(ci);
        if (er == EvaluationResult::TRUE)
            goto label_true;
        if (er == EvaluationResult::FALSE)
            goto label_false;
        if (er == EvaluationResult::UNKNOWN)
            goto label_unknown;
    }
    else if (auto *arg = llvm::dyn_cast<llvm::Argument>(value)) {
        auto er = evalArgument(arg);
        if (er == EvaluationResult::TRUE)
            goto label_true;
        if (er == EvaluationResult::FALSE)
            goto label_false;
        if (er == EvaluationResult::UNKNOWN)
            goto label_unknown;
    }
    // return false by default to keep the result as sound as possible
    label_false:
    curiter->second = EvaluationResult::FALSE;
    return EvaluationResult::FALSE;
    label_true:
    curiter->second = EvaluationResult::TRUE;
    return EvaluationResult::TRUE;
    label_unknown:
    curiter->second = EvaluationResult::UNKNOWN;
    return EvaluationResult::UNKNOWN;
}

FlagAnalysis::EvaluationResult FlagAnalysis::evalBinaryOperator(llvm::BinaryOperator *bo) {
    std::map<llvm::Value*, EvaluationResult>::iterator it_lhs, it_rhs;
    EvaluationResult er_lhs, er_rhs;
    llvm::Value *sbval;
    auto op = bo->getOpcode();
    switch (op) {
    case llvm::Instruction::BinaryOps::And:
        it_lhs = _evalres_.find(bo->getOperand(0));
        it_rhs = _evalres_.find(bo->getOperand(1));
        er_lhs = (it_lhs != _evalres_.end() ? it_lhs->second : isBitSet(bo->getOperand(0)));
        er_rhs = (it_rhs != _evalres_.end() ? it_rhs->second : isBitSet(bo->getOperand(1)));
        if (er_lhs == EvaluationResult::FALSE || er_rhs == EvaluationResult::FALSE)
            return EvaluationResult::FALSE;
        if (er_lhs == EvaluationResult::UNKNOWN || er_rhs == EvaluationResult::UNKNOWN)
            return EvaluationResult::UNKNOWN;
        if (trueOrProcessing(er_lhs) && trueOrProcessing(er_rhs))
            return EvaluationResult::TRUE;
        break;

    case llvm::Instruction::BinaryOps::Or:
        it_lhs = _evalres_.find(bo->getOperand(0));
        it_rhs = _evalres_.find(bo->getOperand(1));
        er_lhs = (it_lhs != _evalres_.end() ? it_lhs->second : isBitSet(bo->getOperand(0)));
        er_rhs = (it_rhs != _evalres_.end() ? it_rhs->second : isBitSet(bo->getOperand(1)));
        if (trueOrProcessing(er_lhs) || trueOrProcessing(er_rhs))
            return EvaluationResult::TRUE;
        if (er_lhs == EvaluationResult::UNKNOWN || er_rhs == EvaluationResult::UNKNOWN)
            return EvaluationResult::UNKNOWN;
        if (er_lhs == EvaluationResult::FALSE && er_rhs == EvaluationResult::FALSE)
            return EvaluationResult::FALSE;
        break;
    case llvm::Instruction::BinaryOps::Xor:
        it_lhs = _evalres_.find(bo->getOperand(0));
        it_rhs = _evalres_.find(bo->getOperand(1));
        er_lhs = (it_lhs != _evalres_.end() ? it_lhs->second : isBitSet(bo->getOperand(0)));
        er_rhs = (it_rhs != _evalres_.end() ? it_rhs->second : isBitSet(bo->getOperand(1)));
        if (er_lhs == EvaluationResult::UNKNOWN || er_rhs == EvaluationResult::UNKNOWN)
            return EvaluationResult::UNKNOWN;
        if (er_lhs == EvaluationResult::TRUE && er_rhs == EvaluationResult::FALSE){
            return EvaluationResult::TRUE;
        }
        if (er_lhs == EvaluationResult::FALSE && er_rhs == EvaluationResult::TRUE){
            return EvaluationResult::TRUE;
        }
        if (er_lhs == EvaluationResult::TRUE && er_rhs == EvaluationResult::TRUE){
            return EvaluationResult::FALSE;
        }
        if (er_lhs == EvaluationResult::FALSE && er_rhs == EvaluationResult::FALSE){
            return EvaluationResult::FALSE;
        }
        break;
    // special cases
    case llvm::Instruction::BinaryOps::Shl:
        sbval = bo->getOperand(1);
        if (auto sbcval = llvm::dyn_cast<llvm::Constant>(sbval)) {
            auto *sbcval_stripped = llvm::dyn_cast<llvm::ConstantInt>(stripConstCastExpr(sbcval));
            uint64_t sb = sbcval_stripped->getZExtValue();
            if (_bit_offset_ >= sb) {
                auto old_bit_offset = _bit_offset_;
                auto old_evalres = _evalres_;
                _evalres_.clear();
                _bit_offset_ -= sb;
                er_lhs = isBitSet(bo->getOperand(0));
                _bit_offset_ = old_bit_offset;
                _evalres_ = old_evalres;
                if (er_lhs == EvaluationResult::TRUE)
                    return EvaluationResult::TRUE;
                if (er_lhs == EvaluationResult::FALSE)
                    return EvaluationResult::FALSE;
                if (er_lhs == EvaluationResult::UNKNOWN)
                    return EvaluationResult::UNKNOWN;
            }
        }
        break;
    case llvm::Instruction::BinaryOps::LShr:
        sbval = bo->getOperand(1);
        if (auto sbcval = llvm::dyn_cast<llvm::Constant>(sbval)) {
            auto *sbcval_stripped = llvm::dyn_cast<llvm::ConstantInt>(stripConstCastExpr(sbcval));
            uint64_t sb = sbcval_stripped->getZExtValue();
            if (_bit_offset_ + sb < 64) {
                auto old_bit_offset = _bit_offset_;
                auto old_evalres = _evalres_;
                _evalres_.clear();
                _bit_offset_ += sb;
                er_lhs = isBitSet(bo->getOperand(0));
                _bit_offset_ = old_bit_offset;
                _evalres_ = old_evalres;
                if (er_lhs == EvaluationResult::TRUE)
                    return EvaluationResult::TRUE;
                if (er_lhs == EvaluationResult::FALSE)
                    return EvaluationResult::FALSE;
                if (er_lhs == EvaluationResult::UNKNOWN)
                    return EvaluationResult::UNKNOWN;
            }
        }
        break;
    default:
        break;
    }
    return EvaluationResult::UNKNOWN;
}

FlagAnalysis::EvaluationResult FlagAnalysis::evalLoadInst(llvm::LoadInst *loadinst) {
    llvm::errs() << "Related LoadInst found @ " << loadinst->getFunction()->getName() << " ";
    print_debugloc(loadinst, llvm::errs());
    llvm::errs() << "\n";
    return EvaluationResult::UNKNOWN;
}

FlagAnalysis::EvaluationResult FlagAnalysis::evalCallInst(llvm::CallInst *callinst) {
    std::vector<llvm::Function*> target_funcs = gCallGraph.findCallTargets(callinst);
    std::vector<llvm::Value*> args;
    std::vector<llvm::ReturnInst *> retinsts;
    bool unknown_flag = 0;
    for (unsigned i = 0; i < callinst->getNumArgOperands(); ++i) {
        args.push_back(callinst->getArgOperand(i));
    }
    _callcontext_.push_back(args);
    for (auto func : target_funcs) {
        retinsts = getReturnInsts(func);
        for (auto retinst : retinsts) {
            if (isBitSet(retinst->getReturnValue()) == EvaluationResult::FALSE)
                goto label_false;
            if (isBitSet(retinst->getReturnValue()) == EvaluationResult::UNKNOWN)
                unknown_flag = 1;
        }
    }
    if (unknown_flag)
        goto label_unknown;
    label_true:
    _callcontext_.pop_back();
    return EvaluationResult::TRUE;
    label_false:
    _callcontext_.pop_back();
    return EvaluationResult::FALSE;
    label_unknown:
    _callcontext_.pop_back();
    return EvaluationResult::UNKNOWN;
}

FlagAnalysis::EvaluationResult FlagAnalysis::evalArgument(llvm::Argument *argument) {
    if (_callcontext_.size() > 0) {
        std::vector<llvm::Value*> topcontext = _callcontext_.back();
        _callcontext_.pop_back();
        auto er = isBitSet(topcontext.at(argument->getArgNo()));
        _callcontext_.push_back(topcontext);
        return er;
    }
    std::set<llvm::Value*> actual_args = gCallGraph.findActualParams(argument);
    if (actual_args.size() == 0)
        return EvaluationResult::UNKNOWN;
    for (auto &aa : actual_args) {
        if (_evalres_.find(aa) != _evalres_.end() && _evalres_[aa] == EvaluationResult::PROCESSING) {
            continue;
        }
        ++_cur_cc_;
        if (_cur_cc_ > _longest_cc_)
            _longest_cc_ = _cur_cc_;
        auto sub_res = isBitSet(aa);
        --_cur_cc_;
        if (sub_res == EvaluationResult::FALSE)
            return EvaluationResult::FALSE;
    }
    return EvaluationResult::TRUE;
}

bool FlagAnalysis::trueOrProcessing(EvaluationResult &er) {
    return er == EvaluationResult::TRUE || er == EvaluationResult::PROCESSING;
}