#include "PageCounterAnalysis.h"
#include "PexCallGraph.h"
#include "AllocatorCollector.h"
#include "FlagAnalysis.h"

extern PexCallGraph gCallGraph;

bool PageCounterAnalysis::checkUserCharging() {
    auto *user_charger = _module_->getFunction("mem_cgroup_charge");
    std::set<llvm::Function*> finished;
    std::deque<std::pair<llvm::Function*, int> > task_queue(1, std::make_pair(user_charger, 0));
    while (!task_queue.empty()) {
        auto cur_func = task_queue.front().first;
        auto cur_hop = task_queue.front().second;
        auto callsites = gCallGraph.findCallSites(cur_func);
        if (finished.count(cur_func) != 0)
            goto cont;
        if (_collector_->isAllocator(cur_func)) {
            for (auto callsite : callsites) {
                auto fa = FlagAnalysis(_collector_->getMemAllocator(cur_func), callsite);
                llvm::errs() << "mem_cgroup_charge is invoked at memory allocation:\n";
                print_debugloc(callsite, llvm::errs());
                llvm::errs() << "The allocator is " << cur_func->getName() << "\n";
                if (fa.getAccountType() == FlagAnalysis::NONE) {
                    llvm::errs() << "The memory is correctly charged.\n";
                }
                else if (fa.getAccountType() == FlagAnalysis::NORMAL) {
                    llvm::errs() << "The memory is mistakenly charged to kmem.\n";
                }
                else if (fa.getAccountType() == FlagAnalysis::KMEM_CACHE_CREATE) {
                    llvm::errs() << "The memory is mistakenly charged to kmem.\n";
                }
                else if (fa.getAccountType() == FlagAnalysis::UNK) {
                    llvm::errs() << "The correctness of memory charging is unknown.\n";
                }
            }
        }
        else if (cur_hop <= 2){
            for (auto callsite : callsites) {
                task_queue.push_back(std::make_pair(callsite->getFunction(), cur_hop + 1));
            }
        }
        finished.insert(cur_func);
        cont:
        task_queue.pop_front();
    }
    return true;
}

bool PageCounterAnalysis::checkSKBCharging() {
    return true;
}