#include "UnitTest.h"
#include "AllocatorCollector.h"
#include "DuplicateAnalysis.h"
#include "MemcgInterfaceCollector.h"
#include "FlagAnalysis.h"
#include "ReferencePaths.h"
#include "PexCallGraph.h"
#include "FreeSiteAnalysis.h"
#include "FreeInterfaceCollector.h"
#include "PageCounterAnalysis.h"

// #define TEST_PEX_CALL_GRAPH
// #define TEST_ALLOCATOR_COLLECTOR
// #define TEST_ALLOCATOR_COLLECTOR_DOT_CALLGRAPH
// #define TEST_SYSCALL_ENTRY
// #define TEST_FLAG_ANALYSIS
// #define TEST_REFERENCE_PATHS
// #define TEST_FREE_SITE_ANALYSIS
// #define TEST_PAGE_COUNTER_ANALYSIS
// #define TEST_MEMCG_INTERFACE_COLLECTOR
// #define TEST_FREE_IF_COLLECTOR
#define TEST_DUP_ANALYSIS
// #define TEST_ALL

extern PexCallGraph gCallGraph;

bool testPexCallGraph(llvm::Module *M) {
#ifdef TEST_PEX_CALL_GRAPH
    auto *func_worker = M->getFunction("store_pan");
    auto callsites = gCallGraph.findCallSites(func_worker);
    llvm::errs() << callsites.size() << "\n";
    for (auto &callsite : callsites) {
        llvm::errs() << callsite->getFunction()->getName() << "\n" << *callsite << "\n";
    }
#endif
    return true;
}

bool testAllocatorCollector(llvm::Module *m) {
#ifdef TEST_ALLOCATOR_COLLECTOR
    AllocatorCollector* a = new AllocatorCollector(*m);
	llvm::errs() << "Allocators:\n";
	std::set<std::string> s;
    for(auto it : a->getAllocateFunctions()) {
        s.insert(to_function_name(it->getName().str()));
	}
    for(auto it : s) {
		llvm::errs() << it << "\n";
	}
#endif

#ifdef TEST_ALLOCATOR_COLLECTOR_DOT_CALLGRAPH
    AllocatorCollector* a = new AllocatorCollector(*m);
	llvm::outs() << "digraph {\n";
	std::set<MemAllocator*> allocator_set;
    for(auto it : a->getAllocateFunctions()) {
        allocator_set.insert(a->getMemAllocator(it));
	}
    std::set<std::string> name_set;
    std::set<std::string> line_set;
    for(auto it : allocator_set) {
        if (it->getRetType()==RET_TYPE::ELSE) {
            name_set.insert(
                "  " 
                + to_function_name(it->getFunction()->getName()) 
                + " [label=\"" 
                + to_function_name(it->getFunction()->getName()) 
                + "\" color=blue style=filled shape=rectangle]\n"
            );
        }
        else {
            if(it->isExported()) {
                name_set.insert(
                    "  " 
                    + to_function_name(it->getFunction()->getName()) 
                    + " [label=\"" 
                    + to_function_name(it->getFunction()->getName()) 
                    + "\" color=Red style=filled]\n"
                );
            } else {
                name_set.insert(
                    "  " 
                    + to_function_name(it->getFunction()->getName()) 
                    + " [label=\"" 
                    + to_function_name(it->getFunction()->getName()) 
                    + "\"]\n"
                );
            }
        }
        
        
	}
    for(auto it : allocator_set) {
        PexCallGraph::CGNode* temp_node = gCallGraph.getNode(it->getFunction());
        for(auto it_2 : temp_node->callees) {
            line_set.insert(
                "  " 
                + to_function_name(temp_node->f->getName())
                + " -> "
                + to_function_name(it_2.first->f->getName())
                + "\n"
            );
        }
	}

    for(auto it : name_set) {
        llvm::outs() << it;
    }
    for(auto it : line_set) {
        llvm::outs() << it;
    }
    llvm::outs() << "}\n";
#endif

    return true;
}

bool testFindSyscallEntry(llvm::Module * M) {
#ifdef TEST_SYSCALL_ENTRY
    llvm::Function* percpu_allocator = M->getFunction("pcpu_alloc");
    llvm::Function* slab_allocator = M->getFunction("__kmalloc");
    llvm::Function* buddy_allocator = M->getFunction("__alloc_pages_nodemask");

    // llvm::errs() << "****percpu****\n";
    // backtrace_syscall_and_print(20, percpu_allocator);

    llvm::errs() << "****slab****\n";
    backtrace_syscall_and_print(10, slab_allocator);

    // llvm::errs() << "****buddy****\n";
    // backtrace_syscall_and_print(20, buddy_allocator);

#endif
    return true;
}

bool testFlagAnalysis(llvm::Module *m) {
#ifdef TEST_FLAG_ANALYSIS
    auto f = m->getFunction("kmem_cache_alloc");
    AllocatorCollector ac(*m);
    auto callsites = gCallGraph.findCallSites(f);
    for (auto callsite : callsites) {
        FlagAnalysis fa(ac.getMemAllocator(f), callsite);
        auto account_type = fa.getAccountType();
        llvm::errs() << "Analysis result for:\n";
        print_debugloc(callsite, llvm::errs());
        if (account_type == FlagAnalysis::AccountType::NORMAL) {
            llvm::errs() << "\nis normal charged.\n";
        }
        else if (account_type == FlagAnalysis::AccountType::KMEM_CACHE_CREATE){
            llvm::errs() << "\nis charged at kmem_cache_create.\n";
        }
        else {
            llvm::errs() << "\nis uncharged.\n";
        }
        // callsite->getDebugLoc().print(llvm::errs());
        // llvm::errs() << "\n";
    }
#endif
    return true;
}

bool testReferencePaths(llvm::Module *m) {
#ifdef  TEST_REFERENCE_PATHS
    auto *fmain = m->getFunction("main");
    auto *fmalloc = m->getFunction("__alloc_pages_nodemask");
    auto callsites = gCallGraph.findCallSites(fmalloc);
    for (auto callsite : callsites) {
        ReferencePaths rp(fmain);
        rp.addPath(callsite, {0});
        rp.print(llvm::errs());
        llvm::errs() << "\n\n";
    }
#endif
    return true;
}

bool testFreeSiteAnalysis(llvm::Module *module) {
#ifdef  TEST_FREE_SITE_ANALYSIS
    // auto *fpos = module->getFunction("assoc_array_clear");
    auto *fmalloc = module->getFunction("vmalloc");
    auto callsites = gCallGraph.findCallSites(fmalloc);
    for (auto callsite : callsites) {
        // if (callsite->getFunction() != fpos)
        //     continue;
        FreeSiteAnalysis fsa(callsite);
        auto freesites = fsa.getFreeSites();
        if (freesites.size() == 0) {
            llvm::errs() << "free site of:\n" << *callsite << "\n" << "not found.\n";
        }
        else {
            for (auto &freesite : freesites) {
                if (freesite.first == callsite->getFunction()) {
                    llvm::errs() << "free site of:\n" << *callsite << "\n";
                    llvm::errs() << "found in the same function " << freesite.first->getName() << " at instruction:\n" << *freesite.second<< "\n";
                }
                else {
                    llvm::errs() << "free site of:\n" << *callsite << "\n";
                    llvm::errs() << "found in another function " << freesite.first->getName() << " at instruction:\n" << *freesite.second<< "\n";
                }
            }
        }
    }
#endif
    return true;
}

bool testPageCounterAnalysis(llvm::Module *m) {
#ifdef  TEST_PAGE_COUNTER_ANALYSIS
    AllocatorCollector ac(*m);
    llvm::errs() << "Allocator collection complete.\n";
    PageCounterAnalysis pca(m, &ac);
    pca.checkUserCharging();
#endif
    return true;
}

bool testMemcgInterfaceCollector(llvm::Module *m) {
#ifdef TEST_MEMCG_INTERFACE_COLLECTOR
    MemcgInterfaceCollector mic(*m);
    mic.collectCharge();
    mic.collectUncharge();
    mic.printGraph(llvm::errs());
#endif
    return true;
}

bool testFreeInterfaceCollector(llvm::Module *m) {
#ifdef TEST_FREE_IF_COLLECTOR
    FreeInterfaceCollector fic(*m);
    fic.getFreeInterfaces();
    fic.printGraph(llvm::errs());
#endif
    return true;
}

bool testDuplicateAnalysis(llvm::Module *m) {
#ifdef TEST_DUP_ANALYSIS
    AllocatorCollector ac(*m);
    DuplicateAnalysis da(*m, &ac);
    da.getResult(DuplicateAnalysis::CHARGE);
    return true;
#endif
}


bool testAll(llvm::Module *module, llvm::raw_ostream &os) {
#ifdef  TEST_ALL
    int num_account_normal = 0;
    int num_account_kmem_cache = 0;
    int num_account_none = 0;
    int num_paths = 0;
    int iter_times = 0;
    std::set<llvm::CallInst *> unaccount_call_sites;
    AllocatorCollector ac(*module);
    auto allocator_funcs = ac.getAllocateFunctions();
    for (auto *allocator_func : allocator_funcs) {
        llvm::errs() << iter_times << "/" << allocator_funcs.size() << " finished.\n";
        llvm::errs() << "current allocator is " << allocator_func->getName() << ".\n";
        ++iter_times;
        auto *allocator = ac.getMemAllocator(allocator_func);
        auto callsites = gCallGraph.findCallSites(allocator_func);
        for (auto *callsite : callsites) {
            if (!ac.isAllocator(callsite->getFunction())) {
                // flag analysis
                FlagAnalysis fa(allocator, callsite);
                auto account_type = fa.getAccountType();
                if (account_type == FlagAnalysis::AccountType::NORMAL) {
                    ++num_account_normal;
                }
                else if (account_type == FlagAnalysis::AccountType::KMEM_CACHE_CREATE) {
                    ++num_account_kmem_cache;
                }
                else if (account_type == FlagAnalysis::AccountType::NONE) {
                    ++num_account_none;
                    // unaccount_call_sites.insert(calliste);
                    os << "Unaccounted allocation site: ";
                    print_debugloc(callsite, os);
                    os << "\n";
                    os.flush();
                    std::vector<llvm::CallInst*> temp_ci;
                    std::set<std::vector<llvm::CallInst*> > result_paths;
                    FreeSiteAnalysis fsa(callsite);
                    temp_ci.push_back(callsite);
                    trace_syscall(temp_ci, result_paths, fsa.getFreeSites());
                    num_paths += result_paths.size();
                    if (!result_paths.empty()) {
                        os << "Paths with alloc-free window found:\n";
                        for (auto &path : result_paths) {
                            for (auto &hop : path) {
                                os << " -> ";
                                print_debugloc(hop, os);
                                os << "@" << hop->getFunction()->getName();
                            }
                            os << "\n";
                        }
                    }
                }
            }
        }
    }
    os << "Total:\n" << "\tAccounted Normal: " << num_account_normal << "\n";
    os << "\t Accounted kmem_cache_create: " << num_account_kmem_cache << "\n";
    os << "\tUnaccounted: " << num_account_none << "\n";
    os << "\tUnaccounted paths with alloc-free window: " << num_paths << "\n";
#endif
    return true;
}